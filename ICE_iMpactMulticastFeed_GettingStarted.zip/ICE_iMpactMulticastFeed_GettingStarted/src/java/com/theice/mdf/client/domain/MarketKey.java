package com.theice.mdf.client.domain;

/**
 * THE CLASSES USED HERE, INCLUDING THE MESSSAGE CLASSES ARE EXAMPLE CODES ONLY.
 * THEY WON'T BE SUPPORTED AS LIBRARY.
 *
 * Market Key interface
 * 
 * @author : Adam Athimuthu
 */
public interface MarketKey 
{
	public int getMarketID(); 
	public boolean isOptions();
}
