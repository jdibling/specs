package com.theice.mdf.message.request;

import java.nio.ByteBuffer;

import com.theice.mdf.message.RawMessageFactory;

/**
 * RequestFeedByMarketType.java
 * @author David Chen
 */
public class TunnelingProxyRequest extends Request
{
    public static final short MESSAGE_LENGTH = 17;

    public long TunnelingMagicNumber;
    public char IsCompressed = 'N';
    public char IsLowLatency = 'N';

    public TunnelingProxyRequest()
    {
        MessageType = RawMessageFactory.TunnelingProxyRequestType;
        MessageBodyLength = MESSAGE_LENGTH - HEADER_LENGTH;
    }

    public synchronized byte[] serialize()
    {
        // Buffer is pre-serialized, so that serialization occurs only once.
        if (SerializedContent == null)
        {
            SerializedContent = ByteBuffer.allocate(MESSAGE_LENGTH);
            serializeHeader();
            SerializedContent.putInt(RequestSeqID);
            SerializedContent.putLong(TunnelingMagicNumber);
            SerializedContent.put((byte) IsCompressed);
            SerializedContent.put((byte) IsLowLatency);
            SerializedContent.rewind();
        }
        return SerializedContent.array();
    }

    public void deserialize(ByteBuffer inboundcontent)
    {
        RequestSeqID = inboundcontent.getInt();
        TunnelingMagicNumber = inboundcontent.getLong();
        if (inboundcontent.hasRemaining())
        {
            IsCompressed = (char) inboundcontent.get();
        }
        if (inboundcontent.hasRemaining())
        {
            IsLowLatency = (char) inboundcontent.get();
        }
    }

    public String toString()
    {
        StringBuilder str = new StringBuilder();
        str.append(super.toString());
        str.append("TunnelingMagicNumber=").append(TunnelingMagicNumber).append(LOG_FLD_DELIMITER);
        str.append("IsCompressed=").append(IsCompressed).append(LOG_FLD_DELIMITER);
        str.append("IsLowLatency=").append(IsLowLatency).append(LOG_FLD_DELIMITER);
        return str.toString();
    }
}
