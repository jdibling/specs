package com.theice.mdf.client.gui.panel;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import com.theice.mdf.client.domain.MarketInterface;
import com.theice.mdf.client.gui.MDFClientFrame;
import com.theice.mdf.client.gui.SpecialFieldsDialog;

/**
 * <code>SpecialFieldsDialogManager</code>
 *
 * @author Barry Fleming
 */
public class SpecialFieldsDialogManager implements ActionListener {
    private SpecialFieldsDialog specialFieldsDialog = null;
    private MarketInterface market = null;

    public synchronized void openSpecialFieldsDialog(MarketInterface market, boolean isProductDefinition) {
        if(null == specialFieldsDialog || isDifferentMarket(market)) {
            if(null != specialFieldsDialog) {
                specialFieldsDialog.dispose();
            }
            specialFieldsDialog = new SpecialFieldsDialog(MDFClientFrame.getInstance(), market, this, isProductDefinition);
            this.market = market;
        } else {
            specialFieldsDialog.setVisible(true);
            specialFieldsDialog.requestFocus();
        }
    }

    private boolean isDifferentMarket(MarketInterface market) {
        return null == this.market || (market.getMarketID() != this.market.getMarketID());
    }

    public synchronized void refresh() {
        if(null != specialFieldsDialog) {
            specialFieldsDialog.refresh();
        }
    }

    @Override
    public synchronized void actionPerformed(ActionEvent e) {
        if (e.getSource() == this.specialFieldsDialog && e.getActionCommand() == SpecialFieldsDialog.CLOSED) {
            this.specialFieldsDialog = null;
        }
    }
}
