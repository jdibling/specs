package com.theice.mdf.client.gui.panel;

import java.text.SimpleDateFormat;
import java.util.List;
import java.util.TimeZone;

import javax.swing.JTextField;

import com.theice.mdf.client.domain.MarketInterface;
import com.theice.mdf.message.ProductDefinitionField;
import com.theice.mdf.message.response.ProductDefinitionResponse;



/**
 * THE CLASSES USED HERE, INCLUDING THE MESSSAGE CLASSES ARE EXAMPLE CODES ONLY.
 * THEY WON'T BE SUPPORTED AS LIBRARY.
 * 
 * @author Barry Fleming
 * Date: Dec 17, 2014
 */
public class SpecialProductDefinitionFieldsPanel extends SpecialFieldsPanel {
    private static final long serialVersionUID = 1L;

    public SpecialProductDefinitionFieldsPanel(MarketInterface market) {
        super(market);
    }


   @Override
   protected void buildSpecialFields() {
      specialFields.put(String.valueOf(ProductDefinitionField.FIELD_ALT_PRICE_DENOMINATOR), new LabelledTextField(ProductDefinitionField.FIELD_NAME_ALT_PRICE_DENOMINATOR, new JTextField(10)));
      specialFields.put(String.valueOf(ProductDefinitionField.FIELD_COUPON_RATE), new LabelledTextField(ProductDefinitionField.FIELD_NAME_COUPON_RATE, new JTextField(10)));
      specialFields.put(String.valueOf(ProductDefinitionField.FIELD_COUPON_RATE_DENOMINATOR), new LabelledTextField(ProductDefinitionField.FIELD_NAME_COUPON_RATE_DENOMINATOR, new JTextField(10)));
      specialFields.put(String.valueOf(ProductDefinitionField.FIELD_DATED_DATE), new LabelledTextField(ProductDefinitionField.FIELD_NAME_DATED_DATE, new JTextField(10)));
      specialFields.put(String.valueOf(ProductDefinitionField.FIELD_INTEREST_ACCRUAL_DATE), new LabelledTextField(ProductDefinitionField.FIELD_NAME_INTEREST_ACCRUAL_DATE, new JTextField(10)));
      specialFields.put(String.valueOf(ProductDefinitionField.FIELD_ISSUE_DATE), new LabelledTextField(ProductDefinitionField.FIELD_NAME_ISSUE_DATE, new JTextField(10)));
      specialFields.put(String.valueOf(ProductDefinitionField.FIELD_REPURCHASE_RATE), new LabelledTextField(ProductDefinitionField.FIELD_NAME_REPURCHASE_RATE, new JTextField(10)));
      specialFields.put(String.valueOf(ProductDefinitionField.FIELD_REPURCHASE_DATE), new LabelledTextField(ProductDefinitionField.FIELD_NAME_REPURCHASE_DATE, new JTextField(10)));
      specialFields.put(String.valueOf(ProductDefinitionField.FIELD_FACTOR), new LabelledTextField(ProductDefinitionField.FIELD_NAME_FACTOR, new JTextField(10)));
      specialFields.put(String.valueOf(ProductDefinitionField.FIELD_INTERPOLATION_FACTOR), new LabelledTextField(ProductDefinitionField.FIELD_NAME_INTERPOLATION_FACTOR, new JTextField(10)));
      specialFields.put(String.valueOf(ProductDefinitionField.FIELD_INTERPOLATION_FACTOR_DENOMINATOR), new LabelledTextField(ProductDefinitionField.FIELD_NAME_INTERPOLATION_FACTOR_DENOMINATOR, new JTextField(10)));
      specialFields.put(String.valueOf(ProductDefinitionField.FIELD_INSTR_REGISTY), new LabelledTextField(ProductDefinitionField.FIELD_NAME_INSTR_REGISTRY, new JTextField(10)));
      specialFields.put(String.valueOf(ProductDefinitionField.FIELD_CREDIT_RATING), new LabelledTextField(ProductDefinitionField.FIELD_NAME_CREDIT_RATING, new JTextField(10)));
      specialFields.put(String.valueOf(ProductDefinitionField.FIELD_ACCRUED_PREMIUM_AMT), new LabelledTextField(ProductDefinitionField.FIELD_NAME_ACCRUED_PREMIUM_AMT, new JTextField(10)));
      specialFields.put(String.valueOf(ProductDefinitionField.FIELD_EVENT_PAYMENT_AMT), new LabelledTextField(ProductDefinitionField.FIELD_NAME_EVENT_PAYMENT_AMT, new JTextField(10)));
      specialFields.put(String.valueOf(ProductDefinitionField.FIELD_ALIGNMENT_INTEREST_RATE), new LabelledTextField(ProductDefinitionField.FIELD_NAME_ALIGNMENT_INTEREST_RATE, new JTextField(10)));
      specialFields.put(String.valueOf(ProductDefinitionField.FIELD_SETTLEMENT_TYPE), new LabelledTextField(ProductDefinitionField.FIELD_NAME_SETTLEMENT_TYPE, new JTextField(10)));
      specialFields.put(String.valueOf(ProductDefinitionField.FIELD_IS_BLOCK_ONLY), new LabelledTextField(ProductDefinitionField.FIELD_NAME_IS_BLOCK_ONLY, new JTextField(10)));
      specialFields.put(String.valueOf(ProductDefinitionField.FIELD_FLEX_ALLOWED), new LabelledTextField(ProductDefinitionField.FIELD_NAME_FLEX_ALLOWED, new JTextField(10)));
      specialFields.put(String.valueOf(ProductDefinitionField.FIELD_HEDGE_MARKET_ID), new LabelledTextField(ProductDefinitionField.FIELD_NAME_HEDGE_MARKET_ID, new JTextField(10)));
    }

    @Override
    public synchronized void refresh() {
        synchronized (market.getUnderlyingMarket()) {
            if(market.getSource() instanceof ProductDefinitionResponse) {
                refreshSpecialFields((ProductDefinitionResponse)market.getSource());
            }
        }
    }

    private void refreshSpecialFields(ProductDefinitionResponse productDefinitionResponse) {
        if(null != productDefinitionResponse) {
            List<ProductDefinitionField> fields = productDefinitionResponse.getFields();
            for (ProductDefinitionField pdf: fields) {
                LabelledTextField ltf = specialFields.get(String.valueOf(pdf.getFieldId()));
                if(null != ltf) {
                   switch (pdf.getFieldId()) {
                      case ProductDefinitionField.FIELD_ALT_PRICE_DENOMINATOR:
                      case ProductDefinitionField.FIELD_INTERPOLATION_FACTOR_DENOMINATOR:
                      case ProductDefinitionField.FIELD_COUPON_RATE_DENOMINATOR:
                      case ProductDefinitionField.FIELD_COUPON_RATE:
                      case ProductDefinitionField.FIELD_REPURCHASE_RATE:
                      case ProductDefinitionField.FIELD_INTERPOLATION_FACTOR:
                      case ProductDefinitionField.FIELD_FACTOR:
                      case ProductDefinitionField.FIELD_ACCRUED_PREMIUM_AMT:
                      case ProductDefinitionField.FIELD_EVENT_PAYMENT_AMT:
                      case ProductDefinitionField.FIELD_ALIGNMENT_INTEREST_RATE:
                      case ProductDefinitionField.FIELD_SETTLEMENT_TYPE:
                      case ProductDefinitionField.FIELD_IS_BLOCK_ONLY:
                      case ProductDefinitionField.FIELD_FLEX_ALLOWED:
                      case ProductDefinitionField.FIELD_HEDGE_MARKET_ID:
                         ltf.textField.setText(String.valueOf(pdf.getValue()));
                         break;
                      case ProductDefinitionField.FIELD_INSTR_REGISTY:
                      case ProductDefinitionField.FIELD_CREDIT_RATING:
                         ltf.textField.setText(toString((char[]) pdf.getValue()));
                         break;
                      case ProductDefinitionField.FIELD_DATED_DATE:
                      case ProductDefinitionField.FIELD_INTEREST_ACCRUAL_DATE:
                      case ProductDefinitionField.FIELD_ISSUE_DATE:
                      case ProductDefinitionField.FIELD_REPURCHASE_DATE:
                         ltf.textField.setText(toDateString((Long) pdf.getValue()));
                         break;
                      default:

                         break;
                   }


                }
            }
        }
    }

   public static final SimpleDateFormat SIMPLE_DATE_FORMAT;
   static {
      SIMPLE_DATE_FORMAT = new SimpleDateFormat("MM/dd/yyyy");
      SIMPLE_DATE_FORMAT.setTimeZone(TimeZone.getTimeZone("UTC"));
   }
   public String toDateString(long val ){

      synchronized (SIMPLE_DATE_FORMAT) {
         return SIMPLE_DATE_FORMAT.format(val);
      }
   }
   public static String toString(char[] rawChars)
   {
      int length = 0;
      for (int i=0; i < rawChars.length; i++)
      {
         if (rawChars[i]=='\0')
         {
            break;
         }

         length++;
      }

      return String.valueOf(rawChars, 0, length);
   }


}
