package com.theice.mdf.message.notification;

import java.nio.ByteBuffer;

import com.theice.mdf.message.MDSequencedMessageWithMarketID;
import com.theice.mdf.message.RawMessageFactory;

public class ClosePriceMessage extends MDSequencedMessageWithMarketID
{
	private static final short MESSAGE_LENGTH = 23;

	public long ClosePrice;
	public long DateTime;

   public ClosePriceMessage()
   {
      MessageType = RawMessageFactory.ClosePriceMessageType;
      MessageBodyLength = MESSAGE_LENGTH - HEADER_LENGTH;
   }

	public synchronized byte[] serialize()
	{
		// Buffer is pre-serialized, so that serialization occurs only once.
		if( SerializedContent == null )
		{
			SerializedContent = ByteBuffer.allocate( MESSAGE_LENGTH );

         serializeHeader();			
			SerializedContent.putLong( ClosePrice );
			SerializedContent.putLong( DateTime );

			SerializedContent.rewind();
         if (SHORT_LOG_STR_PRE_ALLOCATED)
         {
            getShortLogStr();
         }
		}

		return SerializedContent.array();
	}

   public String getShortLogStr()
   {
      if (ShortLogStr==null)
      {
			//noinspection StringBufferReplaceableByString
			StringBuilder strBuf = new StringBuilder();
         strBuf.append( getLogHeaderShortStr());
			
			strBuf.append( ClosePrice );
         strBuf.append( LOG_FLD_DELIMITER );
			strBuf.append( DateTime );
         strBuf.append( LOG_FLD_DELIMITER );

         ShortLogStr = strBuf.toString();
      }

      return ShortLogStr;
   }

	protected void deserializeContent( ByteBuffer inboundcontent )
	{
		ClosePrice = inboundcontent.getLong();
		DateTime = inboundcontent.getLong();
	}

	public String toString()
	{
		//noinspection StringBufferReplaceableByString
		StringBuilder str = new StringBuilder();
      str.append(super.toString());		
		str.append("ClosePrice=");
		str.append(ClosePrice);
		str.append( "|");
		str.append("DateTime=");
		str.append(DateTime);
		str.append( "|");
		return str.toString();
	}

}

	