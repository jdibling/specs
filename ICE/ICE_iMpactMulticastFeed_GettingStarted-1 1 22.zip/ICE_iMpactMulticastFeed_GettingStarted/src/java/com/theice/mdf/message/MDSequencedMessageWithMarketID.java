package com.theice.mdf.message;

import java.nio.ByteBuffer;

/**
 * @author qwang
 * @version %I%, %G% Created: Sep 26, 2007 11:03:36 AM
 */
public abstract class MDSequencedMessageWithMarketID extends MDSequencedMessage
{
   private int marketID = -1;

   public MDSequencedMessageWithMarketID()
   {
      super();
   }

   public MDSequencedMessageWithMarketID(MDSequencedMessageWithMarketID mdMsg)
   {
      super(mdMsg);
      marketID = mdMsg.marketID;
   }

   public String toString()
   {
      return super.toString() + "MarketID=" + marketID + LOG_FLD_DELIMITER;
   }

   protected String[] getFieldTokens(String rawString)
   {
      return rawString.split("\\||=");
   }

   protected void populateHeaderFromString(String[] fields)
   {
      MessageBodyLength = Short.valueOf(fields[3]);
      marketID = Integer.valueOf(fields[7]);
   }

   protected void serializeHeader()
   {
      super.serializeHeader();
      SerializedContent.putInt(marketID);
   }

   protected void deserializeHeader(ByteBuffer inboundcontent)
   {
      marketID = inboundcontent.getInt();
   }

   public String getLogHeaderShortStr()
   {
      return super.getLogHeaderShortStr() + marketID + LOG_FLD_DELIMITER;
   }

   /**
    * @return the marketID
    */
   public int getMarketID()
   {
      return marketID;
   }

   /**
    * @param marketID
    *           the marketID to set
    */
   public void setMarketID(int marketID)
   {
      this.marketID = marketID;
   }

   /**
    * @return
    */
   protected int getLastHeaderFieldIndex()
   {
      return 7;
   }
}
