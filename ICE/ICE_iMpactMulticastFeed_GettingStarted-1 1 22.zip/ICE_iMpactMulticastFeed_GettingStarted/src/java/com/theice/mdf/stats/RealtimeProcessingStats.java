/*
 * This material may not be reproduced or redistributed in whole
 * or in part without the express prior written consent of
 * IntercontinentalExchange, Inc.
 *
 * Copyright IntercontinentalExchange, Inc. 2006, All Rights Reserved.
 */
package com.theice.mdf.stats;

import java.util.Set;

/**
 * @author qwang
 * @version %I%, %G% Created: Dec 6, 2007 10:12:29 AM
 * 
 * 
 */
@SuppressWarnings("unused")
public class RealtimeProcessingStats implements MulticastStats
{
   public static final Object STATS_LOG_HEADER =
      "StatType|GroupAddress|PortNumber|SessionId|BlockSequence|MDEventQueueSize|BookProcessingBeginTime|BookProcessingCompleteTime|MessageQueueSize|SendBeginTime" +
         "|SendCompleteTime|PersistenceQueueSize|PersistenceBeginTime|PersistenceCompleteTime|PersistenceError|CalculateDelta" +
         "|NumberOfMessagesInMDEvent|NumberOfMessageInPLEvent|MessageBlockBytes|SendEpochTimeInMillis|MDEventProcessingDelayTime|NumberOfMessageInBlock|TimeInBufferingSinceLastSent|TotalMessageSizeFromBuffering|MessageIds";
   

   public String toString()
   {
      //noinspection StringBufferReplaceableByString
      StringBuilder builder = new StringBuilder(128);
      builder.append(statType).append('|').append(groupAddress).append('|').append(portNumber).append('|').append(sessionId).append('|');
      builder.append(messageBlockSequenceNumber).append('|').append(mdEventQueueSize).append('|').append(bookProcessingBeginTime).append('|');
      builder.append(bookProcessingCompleteTime).append('|').append(messageQueueSize).append('|').append(messageBlockSendBeginTime).append('|');
      builder.append(messageBlockSendCompleteTime).append('|').append(persistenceQueueSize).append('|').append(messagePersistenceBeginTime).append('|');
      builder.append(messagePersistenceCompleteTime).append('|').append(messagePersistenceError ?"Y":"N").append('|').append(calculateDelta ?"Y":"N").append('|');
      builder.append(numberOfMessagesInMDEvent).append('|').append(numberOfMessagesInPLEvent).append('|').append(messageBlockBytes).append('|');
      builder.append(messageBlockSendEpochTimeInMillis).append('|').append(mdEventProcessingDelayTime).append('|').append(numberOfMessagesInBlock).append('|');
      builder.append(timeInBufferingSinceLastSent).append('|').append(totalMessageSizeFromBuffering).append('|');
      if ( messageIds!=null&&!messageIds.isEmpty()) {
         int idx = 0;
         for (Long id : messageIds) {
            builder.append(id);
            idx++;
            if (idx < messageIds.size())
               builder.append(',');
         }
      }
      return builder.toString();
   }

   private String statType = STAT_TYPE_FULL_ORDER_DEPTH;
   private int mdEventQueueSize;
   private long bookProcessingBeginTime;
   private long bookProcessingCompleteTime;
   private int messageQueueSize;
   private long messageBlockSendBeginTime;
   private long messageBlockSendCompleteTime;
   private int persistenceQueueSize;
   private long messagePersistenceBeginTime;
   private long messagePersistenceCompleteTime;
   private boolean messagePersistenceError;
   private boolean calculateDelta;
   private int numberOfMessagesInMDEvent;
   private int numberOfMessagesInPLEvent;
   private int messageBlockSequenceNumber;
   private int messageBlockBytes;
   private long messageBlockSendEpochTimeInMillis;
   private String groupAddress;
   private int portNumber;
   private short sessionId;
   private long mdEventProcessingDelayTime;
   private int numberOfMessagesInBlock;
   private int totalMessageSizeFromBuffering;
   private int timeInBufferingSinceLastSent;
   private Set<Long> messageIds;

   /**
    * @param stats
    */
   public RealtimeProcessingStats(RealtimeProcessingStats stats)
   {
      statType = stats.statType;
      mdEventQueueSize = stats.mdEventQueueSize;
      bookProcessingBeginTime = stats.bookProcessingBeginTime;
      bookProcessingCompleteTime = stats.bookProcessingCompleteTime;
      messageQueueSize = stats.messageQueueSize;
      messageBlockSendBeginTime = stats.messageBlockSendBeginTime;
      messageBlockSendCompleteTime = stats.messageBlockSendCompleteTime;
      persistenceQueueSize = stats.persistenceQueueSize;
      messagePersistenceBeginTime = stats.messagePersistenceBeginTime;
      messagePersistenceCompleteTime = stats.messagePersistenceCompleteTime;
      messagePersistenceError = stats.messagePersistenceError;
      calculateDelta = stats.calculateDelta;
      numberOfMessagesInMDEvent = stats.numberOfMessagesInMDEvent;
      numberOfMessagesInPLEvent = stats.numberOfMessagesInPLEvent;
      messageBlockSequenceNumber = stats.messageBlockSequenceNumber;
      messageBlockBytes = stats.messageBlockBytes;
      messageBlockSendEpochTimeInMillis = stats.messageBlockSendEpochTimeInMillis;
      groupAddress = stats.groupAddress;
      portNumber = stats.portNumber;
      sessionId = stats.sessionId;
      mdEventProcessingDelayTime = stats.mdEventProcessingDelayTime;
      numberOfMessagesInBlock = stats.numberOfMessagesInBlock;
      totalMessageSizeFromBuffering = stats.totalMessageSizeFromBuffering;
      timeInBufferingSinceLastSent = stats.timeInBufferingSinceLastSent;
      messageIds = null;
   }

   public void reset() {
      mdEventQueueSize = 0;
      bookProcessingBeginTime = 0;
      bookProcessingCompleteTime = 0;
      messageQueueSize = 0;
      messageBlockSendBeginTime = 0;
      messageBlockSendCompleteTime = 0;
      persistenceQueueSize = 0;
      messagePersistenceBeginTime = 0;
      messagePersistenceCompleteTime = 0;
      messagePersistenceError = false;
      calculateDelta = false;
      numberOfMessagesInMDEvent = 0;
      numberOfMessagesInPLEvent = 0;
      messageBlockSequenceNumber = 0;
      messageBlockBytes = 0;
      messageBlockSendEpochTimeInMillis = 0;
      groupAddress = null;
      portNumber = 0;
      sessionId = 0;
      mdEventProcessingDelayTime = 0;
      numberOfMessagesInBlock = 0;
      totalMessageSizeFromBuffering = 0;
      timeInBufferingSinceLastSent = 0;
      messageIds = null;
   }

   
   /**
    * @return the groupAddress
    */
   public String getGroupAddress()
   {
      return groupAddress;
   }
   /**
    * @param groupAddress the groupAddress to set
    */
   public void setGroupAddress(String groupAddress)
   {
      this.groupAddress = groupAddress;
   }
   /**
    * @return the portNumber
    */
   public int getPortNumber()
   {
      return portNumber;
   }
   /**
    * @param portNumber the portNumber to set
    */
   public void setPortNumber(int portNumber)
   {
      this.portNumber = portNumber;
   }
   /**
    * @return the sessionId
    */
   public short getSessionId()
   {
      return sessionId;
   }
   /**
    * @param sessionId the sessionId to set
    */
   public void setSessionId(short sessionId)
   {
      this.sessionId = sessionId;
   }
   public RealtimeProcessingStats()
   {}

   /**
    * @return the bookProcessingBeginTime
    */
   public long getBookProcessingBeginTime()
   {
      return bookProcessingBeginTime;
   }

   /**
    * @param bookProcessingBeginTime
    *           the bookProcessingBeginTime to set
    */
   public void setBookProcessingBeginTime(long bookProcessingBeginTime)
   {
      this.bookProcessingBeginTime = bookProcessingBeginTime;
   }

   /**
    * @return the bookProcessingCompleteTime
    */
   public long getBookProcessingCompleteTime()
   {
      return bookProcessingCompleteTime;
   }

   /**
    * @param bookProcessingCompleteTime
    *           the bookProcessingCompleteTime to set
    */
   public void setBookProcessingCompleteTime(long bookProcessingCompleteTime)
   {
      this.bookProcessingCompleteTime = bookProcessingCompleteTime;
   }

   /**
    * @return the mdEventQueueSize
    */
   public int getMdEventQueueSize()
   {
      return mdEventQueueSize;
   }

   /**
    * @param mdEventQueueSize
    *           the mdEventQueueSize to set
    */
   public void setMdEventQueueSize(int mdEventQueueSize)
   {
      this.mdEventQueueSize = mdEventQueueSize;
   }

   /**
    * @return the messageBlockSendBeginTime
    */
   public long getMessageBlockSendBeginTime()
   {
      return messageBlockSendBeginTime;
   }

   /**
    * @param messageBlockSendBeginTime
    *           the messageBlockSendBeginTime to set
    */
   public void setMessageBlockSendBeginTime(long messageBlockSendBeginTime)
   {
      this.messageBlockSendBeginTime = messageBlockSendBeginTime;
   }

   /**
    * @return the messageBlockSendCompleteTime
    */
   public long getMessageBlockSendCompleteTime()
   {
      return messageBlockSendCompleteTime;
   }

   /**
    * @param messageBlockSendCompleteTime
    *           the messageBlockSendCompleteTime to set
    */
   public void setMessageBlockSendCompleteTime(long messageBlockSendCompleteTime)
   {
      this.messageBlockSendCompleteTime = messageBlockSendCompleteTime;
   }

   /**
    * @return the messagePersistenceBeginTime
    */
   public long getMessagePersistenceBeginTime()
   {
      return messagePersistenceBeginTime;
   }

   /**
    * @param messagePersistenceBeginTime
    *           the messagePersistenceBeginTime to set
    */
   public void setMessagePersistenceBeginTime(long messagePersistenceBeginTime)
   {
      this.messagePersistenceBeginTime = messagePersistenceBeginTime;
   }

   /**
    * @return the messagePersistenceCompleteTime
    */
   public long getMessagePersistenceCompleteTime()
   {
      return messagePersistenceCompleteTime;
   }

   /**
    * @param messagePersistenceCompleteTime
    *           the messagePersistenceCompleteTime to set
    */
   public void setMessagePersistenceCompleteTime(long messagePersistenceCompleteTime)
   {
      this.messagePersistenceCompleteTime = messagePersistenceCompleteTime;
   }

   /**
    * @return the bookType
    */
   public String getStatType()
   {
      return statType;
   }

   /**
    * @param statType
    *           the bookType to set
    */
   public void setStatType(String statType)
   {
      this.statType = statType;
   }

   /**
    * @return the messageQueueSize
    */
   public int getMessageQueueSize()
   {
      return messageQueueSize;
   }

   /**
    * @param messageQueueSize
    *           the messageQueueSize to set
    */
   public void setMessageQueueSize(int messageQueueSize)
   {
      this.messageQueueSize = messageQueueSize;
   }

   /**
    * @return the persistenceQueueSize
    */
   public int getPersistenceQueueSize()
   {
      return persistenceQueueSize;
   }

   /**
    * @param persistenceQueueSize
    *           the persistenceQueueSize to set
    */
   public void setPersistenceQueueSize(int persistenceQueueSize)
   {
      this.persistenceQueueSize = persistenceQueueSize;
   }

   /**
    * @return the calculateDelta
    */
   public boolean isCalculateDelta()
   {
      return calculateDelta;
   }

   /**
    * @param calculateDelta
    *           the calculateDelta to set
    */
   public void setCalculateDelta(boolean calculateDelta)
   {
      this.calculateDelta = calculateDelta;
   }

   /**
    * @return the numberOfMessagesInMDEvent
    */
   public int getNumberOfMessagesInMDEvent()
   {
      return numberOfMessagesInMDEvent;
   }

   /**
    * @param numberOfMessagesInMDEvent
    *           the numberOfMessagesInMDEvent to set
    */
   public void setNumberOfMessagesInMDEvent(int numberOfMessagesInMDEvent)
   {
      this.numberOfMessagesInMDEvent = numberOfMessagesInMDEvent;
   }

   /**
    * @return the numberOfMessagesInPLEvent
    */
   public int getNumberOfMessagesInPLEvent()
   {
      return numberOfMessagesInPLEvent;
   }

   /**
    * @param numberOfMessagesInPLEvent
    *           the numberOfMessagesInPLEvent to set
    */
   public void setNumberOfMessagesInPLEvent(int numberOfMessagesInPLEvent)
   {
      this.numberOfMessagesInPLEvent = numberOfMessagesInPLEvent;
   }

   /**
    * @return the messageBlockSequenceNumber
    */
   public int getMessageBlockSequenceNumber()
   {
      return messageBlockSequenceNumber;
   }

   /**
    * @param messageBlockSequenceNumber
    *           the messageBlockSequenceNumber to set
    */
   public void setMessageBlockSequenceNumber(int messageBlockSequenceNumber)
   {
      this.messageBlockSequenceNumber = messageBlockSequenceNumber;
   }

   /**
    * @return the messagePersistenceError
    */
   public boolean isMessagePersistenceError()
   {
      return messagePersistenceError;
   }

   /**
    * @param messagePersistenceError
    *           the messagePersistenceError to set
    */
   public void setMessagePersistenceError(boolean messagePersistenceError)
   {
      this.messagePersistenceError = messagePersistenceError;
   }

   /**
    * @return the messageBlockBytes
    */
   public int getMessageBlockBytes()
   {
      return messageBlockBytes;
   }
   /**
    * @param messageBlockBytes the messageBlockBytes to set
    */
   public void setMessageBlockBytes(int messageBlockBytes)
   {
      this.messageBlockBytes = messageBlockBytes;
   }
   /**
    * @return the messageBlockSendEpochTimeInMillis
    */
   public long getMessageBlockSendEpochTimeInMillis()
   {
      return messageBlockSendEpochTimeInMillis;
   }
   /**
    * @param messageBlockSendEpochTimeInMillis the messageBlockSendEpochTimeInMillis to set
    */
   public void setMessageBlockSendEpochTimeInMillis(long messageBlockSendEpochTimeInMillis)
   {
      this.messageBlockSendEpochTimeInMillis = messageBlockSendEpochTimeInMillis;
   }
   /**
    * @see com.theice.mdf.stats.MulticastStats#copy()
    */
   public MulticastStats copy()
   {
      return new RealtimeProcessingStats(this);
   }

   /**
    * @return the mdEventProcessingDelayTime
    */
   public long getMdEventProcessingDelayTime()
   {
      return mdEventProcessingDelayTime;
   }

   /**
    * @param mdEventProcessingDelayTime the mdEventProcessingDelayTime to set
    */
   public void setMdEventProcessingDelayTime(long mdEventProcessingDelayTime)
   {
      this.mdEventProcessingDelayTime = mdEventProcessingDelayTime;
   }

   /**
    * @return the numberOfMessagesInBlock
    */
   public int getNumberOfMessagesInBlock()
   {
      return numberOfMessagesInBlock;
   }

   /**
    * @param numberOfMessagesInBlock the numberOfMessagesInBlock to set
    */
   public void setNumberOfMessagesInBlock(int numberOfMessagesInBlock)
   {
      this.numberOfMessagesInBlock = numberOfMessagesInBlock;
   }

   public void setTotalMessageSizeFromBuffering(int totalMessageSizeFromBuffering)
   {
      this.totalMessageSizeFromBuffering = totalMessageSizeFromBuffering;
   }

   public void setTimeInBufferingSinceLastSent(int timeInBufferingSinceLastSent)
   {
      this.timeInBufferingSinceLastSent = timeInBufferingSinceLastSent;
   }

   @Override
   public Set<Long> getMessageIds() {
      return messageIds;
   }

   @Override
   public void setMessageIds(Set<Long> messageIds) {
      this.messageIds = messageIds;
   }
}
