package com.theice.mdf.message;

import com.theice.mdf.message.notification.SpecialFieldMessage;

/**
 * User: dkim
 * Date: 10/21/14
 * Time: 1:35 PM
 */
public interface SupportSpecialFieldMessage {
   SpecialFieldMessage getSpecialFieldMessage();
   void setSpecialFieldMessage(SpecialFieldMessage message);
   void addField( byte fieldId, Object value );
   Object getFieldValue( byte fieldId );
}
