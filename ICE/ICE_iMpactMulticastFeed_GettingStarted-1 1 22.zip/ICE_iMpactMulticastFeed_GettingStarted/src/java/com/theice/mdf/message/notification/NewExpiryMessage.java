package com.theice.mdf.message.notification;

import java.nio.ByteBuffer;

import com.theice.mdf.message.MDSequencedMessageWithMarketID;
import com.theice.mdf.message.MessageUtil;
import com.theice.mdf.message.RawMessageFactory;

public class NewExpiryMessage extends MDSequencedMessageWithMarketID
{
   private static final short MESSAGE_LENGTH = 472;
   
   public short MarketTypeID;
   public char OrderPriceDenominator;
   public int IncrementPrice;
   public int IncrementQty;
   public int LotSize;     
   public char MarketDesc[] = new char[120];
   public short MaturityYear;
   public short MaturityMonth;
   public short MaturityDay;
   public char DealPriceDenominator;
   public int MinQty;
   public int UnitQty;
   public char Currency[] = new char[20];
   public char ClearedAlias[] = new char[15];
   public long MinPrice;
   public long MaxPrice; 
   public int ProductID;
   public char ProductName[] = new char[62];
   public int HubID;
   public char HubAlias[] = new char[80];
   public int StripID;
   public char StripName[] = new char[39];
   public char SettlePriceDenominator;
   public char MICCode[] = new char[4];
   public char UnitQtyDenominator = '0';
   public char OffExchangeIncrementQtyDenominator = '0';
   public int OffExchangeIncrementQty;
   public int OffExchangeIncrementPrice;
   public int OffExchangeIncrementOptionPrice;
   public char ContractSymbol[] = new char[35];
   public char ISIN[] = new char[12];
   public char NumDecimalsOptionsPrice;
   public int HedgeMarketId;
   public NewExpiryMessage()
   {
      MessageType = RawMessageFactory.NewExpiryMessageType;
      MessageBodyLength = MESSAGE_LENGTH - HEADER_LENGTH;
   }

   public synchronized byte[] serialize()
   {
      // Buffer is pre-serialized, so that serialization occurs only once.
      if( SerializedContent == null )
      {
         SerializedContent = ByteBuffer.allocate( MESSAGE_LENGTH );
      
         serializeHeader();
         
         SerializedContent.putShort(MarketTypeID);
         SerializedContent.put((byte)OrderPriceDenominator);
         SerializedContent.putInt(IncrementPrice);
         SerializedContent.putInt(IncrementQty);
         SerializedContent.putInt(LotSize);
         
         for( int i=0; i<MarketDesc.length; i++ )
         {
            SerializedContent.put( (byte)MarketDesc[i] );
         }
      
         SerializedContent.putShort(MaturityYear);
         SerializedContent.putShort(MaturityMonth);
         SerializedContent.putShort(MaturityDay);
         SerializedContent.put((byte)DealPriceDenominator);
         SerializedContent.putInt(MinQty);
         SerializedContent.putInt(UnitQty);

         for( int i=0; i<Currency.length; i++ )
         {
            SerializedContent.put( (byte)Currency[i] );
         }
         
         for( int i=0; i<ClearedAlias.length; i++ )
         {
            SerializedContent.put( (byte)ClearedAlias[i] );
         }
         
         SerializedContent.putLong(MinPrice);
         SerializedContent.putLong(MaxPrice);
         SerializedContent.putInt(ProductID);
         for( int i=0; i<ProductName.length; i++ )
         {
            SerializedContent.put( (byte)ProductName[i] );
         }
         SerializedContent.putInt(HubID);
         for( int i=0; i<HubAlias.length; i++ )
         {
            SerializedContent.put( (byte)HubAlias[i] );
         }
         SerializedContent.putInt(StripID);
         for( int i=0; i<StripName.length; i++ )
         {
            SerializedContent.put( (byte)StripName[i] );
         }
                  
         SerializedContent.put( (byte)SettlePriceDenominator );
         
         for( int i=0; i<MICCode.length; i++ )
         {
            SerializedContent.put( (byte)MICCode[i] );
         }          

         SerializedContent.put( (byte)UnitQtyDenominator );
         SerializedContent.put((byte)OffExchangeIncrementQtyDenominator);
         SerializedContent.putInt( OffExchangeIncrementQty );
         SerializedContent.putInt( OffExchangeIncrementPrice );
         SerializedContent.putInt( OffExchangeIncrementOptionPrice );
         for( int i=0; i<ContractSymbol.length; i++ )
         {
            SerializedContent.put( (byte)ContractSymbol[i] );
         }

         for( int i=0; i<ISIN.length; i++ )
         {
            SerializedContent.put( (byte)ISIN[i] );
         }
         SerializedContent.put((byte) NumDecimalsOptionsPrice);
         SerializedContent.putInt(HedgeMarketId);
         SerializedContent.rewind();
      }
      
      return SerializedContent.array();
   }
   
   public String getShortLogStr()
   {
      // too much for logging, and it is pretty static, just
      // return null
      return null;
   }
   
   public void deserializeContent( ByteBuffer inboundcontent )
   {
      MarketTypeID = inboundcontent.getShort();
      OrderPriceDenominator = (char)inboundcontent.get();
      IncrementPrice = inboundcontent.getInt();
      IncrementQty = inboundcontent.getInt();
      LotSize = inboundcontent.getInt();
      
      for( int i=0; i<MarketDesc.length; i++ )
      {
         MarketDesc[i] = (char)inboundcontent.get();
      }
      
      MaturityYear = inboundcontent.getShort();
      MaturityMonth = inboundcontent.getShort();
      MaturityDay = inboundcontent.getShort();
      DealPriceDenominator = (char)inboundcontent.get();
      MinQty = inboundcontent.getInt();
      UnitQty = inboundcontent.getInt();
      
      for( int i=0; i<Currency.length; i++ )
      {
         Currency[i] = (char)inboundcontent.get();
      }    
      for( int i=0; i<ClearedAlias.length; i++ )
      {
         ClearedAlias[i] = (char)inboundcontent.get();
      }    
      
      MinPrice = inboundcontent.getLong();
      MaxPrice = inboundcontent.getLong();
      ProductID = inboundcontent.getInt();
      for( int i=0; i<ProductName.length; i++ )
      {
         ProductName[i] = (char)inboundcontent.get();
      }    
      HubID = inboundcontent.getInt();
      for( int i=0; i<HubAlias.length; i++ )
      {
         HubAlias[i] = (char)inboundcontent.get();
      }    
      StripID = inboundcontent.getInt();
      for( int i=0; i<StripName.length; i++ )
      {
         StripName[i] = (char)inboundcontent.get();
      }    
      
      SettlePriceDenominator = (char)inboundcontent.get();
      for( int i=0; i<MICCode.length; i++ )
      {
         MICCode[i] = (char)inboundcontent.get();
      }    
     	
      UnitQtyDenominator = (char)inboundcontent.get();
      
      if(inboundcontent.remaining()>0)
      {
         OffExchangeIncrementQtyDenominator = (char)inboundcontent.get();
         OffExchangeIncrementQty = inboundcontent.getInt();
         OffExchangeIncrementPrice = inboundcontent.getInt();
         OffExchangeIncrementOptionPrice = inboundcontent.getInt();
         for( int i=0; i<ContractSymbol.length; i++ )
         {
            ContractSymbol[i] = (char)inboundcontent.get();
         }
      }
      for( int i=0; i<ISIN.length; i++ )
      {
         ISIN[i] = (char)inboundcontent.get();
      }
      if(inboundcontent.remaining()>0)
      {
         NumDecimalsOptionsPrice=(char) inboundcontent.get();
         HedgeMarketId=inboundcontent.getInt();
      }
   }
   
   public String toString()
   {
      //noinspection StringBufferReplaceableByString
      StringBuilder str = new StringBuilder();
      
      str.append(super.toString());
      str.append("MarketTypeID=");
      str.append(MarketTypeID);
      str.append( "|");
      str.append("OrderPriceDenominator=");
      str.append(OrderPriceDenominator);
      str.append( "|");
      str.append("IncrementPrice=");
      str.append(IncrementPrice);
      str.append( "|");
      str.append("IncrementQty=");
      str.append(IncrementQty);
      str.append( "|");
      str.append("LotSize=");
      str.append(LotSize);
      str.append( "|");
      str.append("MarketDesc=");
      str.append(MessageUtil.toString(MarketDesc));
      str.append( "|");
      str.append("MaturityYear=");
      str.append(MaturityYear);
      str.append( "|");
      str.append("MaturityMonth=");
      str.append(MaturityMonth);
      str.append( "|");
      str.append("MaturityDay=");
      str.append(MaturityDay);
      str.append( "|");
      str.append("DealPriceDenominator=");
      str.append(DealPriceDenominator);
      str.append("|");
      str.append("MinQty=");
      str.append(MinQty);
      str.append( "|");
      str.append("UnitQty=");
      str.append(UnitQty);
      str.append( "|");
      str.append("Currency=");
      str.append(MessageUtil.toString(Currency));
      str.append( "|");
      str.append("ClearedAlias=");
      str.append(MessageUtil.toString(ClearedAlias));
      str.append( "|");
      str.append("MinPrice=");
      str.append(MinPrice);
      str.append( "|");
      str.append("MaxPrice=");
      str.append(MaxPrice);
      str.append( "|");
      str.append("ProductID=");
      str.append(ProductID);
      str.append( "|");
      str.append("ProductName=");
      str.append(MessageUtil.toString(ProductName));
      str.append( "|");
      str.append("HubID=");
      str.append(HubID);
      str.append( "|");
      str.append("HubAlias=");
      str.append(MessageUtil.toString(HubAlias));
      str.append( "|");
      str.append("StripID=");
      str.append(StripID);
      str.append( "|");
      str.append("StripName=");
      str.append(MessageUtil.toString(StripName));
      str.append( "|");
      str.append("SettlePriceDenominator=");
      str.append(SettlePriceDenominator);
      str.append("|");
      str.append("MICCode=");
      str.append(MessageUtil.toString(MICCode));
      str.append( "|");
      str.append("UnitQtyDenominator=");
      str.append(UnitQtyDenominator);
      str.append("|");
      str.append("ContractSymbol=");
      str.append(MessageUtil.toString(ContractSymbol));
      str.append( "|");
      str.append("OffExchangeIncrementQtyDenominator=");
      str.append(OffExchangeIncrementQtyDenominator);
      str.append("|");
      str.append("OffExchangeIncrementQty=");
      str.append(OffExchangeIncrementQty);
      str.append("|");
      str.append("OffExchangeIncrementPrice=");
      str.append(OffExchangeIncrementPrice);
      str.append("|");
      str.append("OffExchangeIncrementOptionPrice=");
      str.append(OffExchangeIncrementOptionPrice);
      str.append("|");
      str.append("ISIN=");
      str.append(MessageUtil.toString(ISIN));
      str.append("|");
      str.append("NumDecimalsOptionsPrice=");
      str.append(NumDecimalsOptionsPrice);
      str.append("|");
      str.append("HedgeMarketId=");
      str.append(HedgeMarketId);
      str.append("|");
      return str.toString();
   }
   
}