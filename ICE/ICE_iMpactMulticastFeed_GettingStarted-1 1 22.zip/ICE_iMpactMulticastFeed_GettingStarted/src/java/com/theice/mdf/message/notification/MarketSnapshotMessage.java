package com.theice.mdf.message.notification;

import com.theice.mdf.message.MDSequencedMessageWithMarketIDSpecialFields;
import com.theice.mdf.message.RawMessageFactory;
import com.theice.mdf.message.SnapshotMessageIface;

import java.nio.ByteBuffer;

/**
 * MarketSnapshotMessage.java
 * @author David Chen
 */

public class MarketSnapshotMessage extends MDSequencedMessageWithMarketIDSpecialFields implements SnapshotMessageIface
{
   private static final short MESSAGE_LENGTH = 136;
   public static final byte OPEN_INTEREST_DATE_LENGTH = 10;

   public short MarketType;
   public char TradingStatus;
   public int TotalVolume;
   public int BlockVolume;
   public int EFSVolume;
   public int EFPVolume;
   public int OpenInterest;
   public long OpeningPrice;
   public long SettlementPriceWithDealPricePrecision;
   public long High;
   public long Low;
   public long VWAP;
   public int NumOfBookEntries;
   public long LastTradePrice;
   public int LastTradeQuantity;
   public long LastTradeDateTime;
   public long SettlementPriceDateTime = -1;
   public int LastMessageSequenceNumber;
   public short ReservedField1;
   public char[] OpenInterestDate = new char[OPEN_INTEREST_DATE_LENGTH];
   public char IsSettlementPriceOfficial = 'N';
   public long SettlementPrice;
   public char HasPrevDaySettlementPrice = 'N';
   public long PrevDaySettlementPrice;


   public MarketSnapshotMessage()
   {
      MessageType = RawMessageFactory.MarketSnapshotMessageType;
      MessageBodyLength = MESSAGE_LENGTH - HEADER_LENGTH;
   }

   public synchronized byte[] serialize()
   {
      // Buffer is pre-serialized, so that serialization occurs only once.
      if( SerializedContent == null )
      {
         SerializedContent = ByteBuffer.allocate( MESSAGE_LENGTH );

         serializeHeader();
         SerializedContent.putShort( MarketType );
         SerializedContent.put( (byte)TradingStatus );
         SerializedContent.putInt( TotalVolume );
         SerializedContent.putInt( BlockVolume );
         SerializedContent.putInt( EFSVolume );
         SerializedContent.putInt( EFPVolume );
         SerializedContent.putInt( OpenInterest );
         SerializedContent.putLong( OpeningPrice );
         SerializedContent.putLong( SettlementPriceWithDealPricePrecision );
         SerializedContent.putLong( High );
         SerializedContent.putLong( Low );
         SerializedContent.putLong( VWAP );
         SerializedContent.putInt( NumOfBookEntries );
         SerializedContent.putLong(LastTradePrice);
         SerializedContent.putInt(LastTradeQuantity);
         SerializedContent.putLong(LastTradeDateTime);
         SerializedContent.putLong(SettlementPriceDateTime);
         SerializedContent.putInt(LastMessageSequenceNumber);
         SerializedContent.putShort(ReservedField1);
         for( int i=0; i<OPEN_INTEREST_DATE_LENGTH; i++ )
         {
            SerializedContent.put( (byte)OpenInterestDate[i] );
         }
         SerializedContent.put( (byte)IsSettlementPriceOfficial );
         SerializedContent.putLong( SettlementPrice );
         SerializedContent.put( (byte) HasPrevDaySettlementPrice );
         SerializedContent.putLong( PrevDaySettlementPrice);

         SerializedContent.rewind();

         if (SHORT_LOG_STR_PRE_ALLOCATED)
         {
            getShortLogStr();
         }
      }

      return SerializedContent.array();
   }

   public String getShortLogStr()
   {
      if (ShortLogStr==null)
      {
         //noinspection StringBufferReplaceableByString
         StringBuilder strBuf = new StringBuilder();
         strBuf.append( getLogHeaderShortStr());

         strBuf.append( LOG_FLD_DELIMITER );
         strBuf.append( MarketType );
         strBuf.append( LOG_FLD_DELIMITER );
         strBuf.append( (byte)TradingStatus );
         strBuf.append( LOG_FLD_DELIMITER );
         strBuf.append(  TotalVolume );
         strBuf.append( LOG_FLD_DELIMITER );
         strBuf.append(  BlockVolume );
         strBuf.append( LOG_FLD_DELIMITER );
         strBuf.append(  EFSVolume );
         strBuf.append( LOG_FLD_DELIMITER );
         strBuf.append(  EFPVolume );
         strBuf.append( LOG_FLD_DELIMITER );
         strBuf.append(  OpenInterest );
         strBuf.append( LOG_FLD_DELIMITER );
         strBuf.append(  OpeningPrice );
         strBuf.append( LOG_FLD_DELIMITER );
         strBuf.append( SettlementPriceWithDealPricePrecision );
         strBuf.append( LOG_FLD_DELIMITER );
         strBuf.append( High );
         strBuf.append( LOG_FLD_DELIMITER );
         strBuf.append( Low );
         strBuf.append( LOG_FLD_DELIMITER );
         strBuf.append( VWAP );
         strBuf.append( LOG_FLD_DELIMITER );
         strBuf.append(  NumOfBookEntries );
         strBuf.append( LOG_FLD_DELIMITER );
         strBuf.append(  LastTradePrice );
         strBuf.append( LOG_FLD_DELIMITER );
         strBuf.append(  LastTradeQuantity );
         strBuf.append( LOG_FLD_DELIMITER );
         strBuf.append(  LastTradeDateTime );
         strBuf.append( LOG_FLD_DELIMITER );
         strBuf.append(  SettlementPriceDateTime );
         strBuf.append( LOG_FLD_DELIMITER );
         strBuf.append(  LastMessageSequenceNumber );
         strBuf.append( LOG_FLD_DELIMITER );
         strBuf.append(  ReservedField1 );
         strBuf.append( LOG_FLD_DELIMITER);
         strBuf.append( OpenInterestDate );
         strBuf.append( LOG_FLD_DELIMITER );
         strBuf.append( IsSettlementPriceOfficial );
         strBuf.append( LOG_FLD_DELIMITER );
         strBuf.append( SettlementPrice );
         strBuf.append( LOG_FLD_DELIMITER );
         strBuf.append( HasPrevDaySettlementPrice );
         strBuf.append( LOG_FLD_DELIMITER );
         strBuf.append( HasPrevDaySettlementPrice );
         strBuf.append( LOG_FLD_DELIMITER );
         ShortLogStr = strBuf.toString();
      }

      return ShortLogStr;
   }


   public void deserializeContent( ByteBuffer inboundcontent )
   {
      MarketType = inboundcontent.getShort();
      TradingStatus = (char)inboundcontent.get();
      TotalVolume = inboundcontent.getInt();
      BlockVolume = inboundcontent.getInt();
      EFSVolume = inboundcontent.getInt();
      EFPVolume = inboundcontent.getInt();
      OpenInterest = inboundcontent.getInt();
      OpeningPrice = inboundcontent.getLong();
      SettlementPriceWithDealPricePrecision = inboundcontent.getLong();
      High = inboundcontent.getLong();
      Low = inboundcontent.getLong();
      VWAP = inboundcontent.getLong();
      NumOfBookEntries = inboundcontent.getInt();
      LastTradePrice = inboundcontent.getLong();
      LastTradeQuantity = inboundcontent.getInt();
      LastTradeDateTime = inboundcontent.getLong();
      SettlementPriceDateTime = inboundcontent.getLong();
      LastMessageSequenceNumber = inboundcontent.getInt();
      ReservedField1 = inboundcontent.getShort();

      for( int i=0; i<OPEN_INTEREST_DATE_LENGTH  ; i++ )
      {
         OpenInterestDate[i] = (char)inboundcontent.get();
      }

      IsSettlementPriceOfficial = (char)inboundcontent.get();

      SettlementPrice = inboundcontent.getLong();
      if (inboundcontent.hasRemaining())
      {
         HasPrevDaySettlementPrice = (char)inboundcontent.get();
         PrevDaySettlementPrice = inboundcontent.getLong();
      }
   }

   public String toString()
   {
      //noinspection StringBufferReplaceableByString
      StringBuilder str = new StringBuilder();

      str.append(super.toString());
      str.append("MarketType=");
      str.append(MarketType);
      str.append( "|");
      str.append("Status=");
      str.append(TradingStatus);
      str.append( "|");
      str.append("TotalVol=");
      str.append(TotalVolume);
      str.append( "|");
      str.append("BlkVol=");
      str.append(BlockVolume);
      str.append( "|");
      str.append("EFSVol=");
      str.append(EFSVolume);
      str.append( "|");
      str.append("EFPVol=");
      str.append(EFPVolume);
      str.append( "|");
      str.append("OI=");
      str.append(OpenInterest);
      str.append( "|");
      str.append("OP=");
      str.append(OpeningPrice);
      str.append( "|");
      str.append("SPOld=");
      str.append(SettlementPriceWithDealPricePrecision);
      str.append( "|");
      str.append("High=");
      str.append(High);
      str.append( "|");
      str.append("Low=");
      str.append(Low);
      str.append( "|");
      str.append("VWAP=");
      str.append(VWAP);
      str.append( "|");
      str.append("NumBkEntries=");
      str.append(NumOfBookEntries);
      str.append( "|");
      str.append("LTP=");
      str.append(LastTradePrice);
      str.append( "|");
      str.append("LTQ=");
      str.append(LastTradeQuantity);
      str.append( "|");
      str.append("LTDT=");
      str.append(LastTradeDateTime);
      str.append( "|");
      str.append("SPDT=");
      str.append(SettlementPriceDateTime);
      str.append( "|");
      str.append("LstMsgSeqNum=");
      str.append(LastMessageSequenceNumber);
      str.append( "|");
      str.append("RSVDFld1=");
      str.append(ReservedField1);
      str.append( "|");
      str.append("OIDate=");
      str.append(OpenInterestDate);
      str.append( "|");
      str.append("IsSPO=");
      str.append(IsSettlementPriceOfficial);
      str.append( "|");
      str.append("SP=");
      str.append(SettlementPrice);
      str.append( "|");
      str.append("HasPDSP=");
      str.append(HasPrevDaySettlementPrice);
      str.append( "|");
      str.append("PDSP=");
      str.append(PrevDaySettlementPrice);
      str.append( "|");

      return str.toString();
   }

   /**
    * Methods to support SnapshotMessageIface interface contracts
    */

   public int getNumOfBookEntries()
   {
      return(this.NumOfBookEntries);
   }

   public int getLastMessageSequenceNumber()
   {
      return(this.LastMessageSequenceNumber);
   }

}

