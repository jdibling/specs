package com.theice.mdf.client.domain;

import com.theice.mdf.message.MDSequencedMessageWithMarketIDSpecialFields;
import com.theice.mdf.message.SpecialFieldValue;
import com.theice.mdf.message.notification.MarketSnapshotMessage;
import com.theice.mdf.message.notification.OpenPriceMessage;
import com.theice.mdf.message.notification.TradeMessage;

/**
 * <code>SpecialFields</code>
 *
 * @author Barry Fleming
 */
public class SpecialField {
   public static final String ALT_PRICE_PREFIX_OPEN = "Open ";
   //public static final String ALT_PRICE_PREFIX_SETTLE = "Settle ";
   public static final String ALT_LAST_TRADE = "AltLastTrade";

   private final SpecialFieldValue value;
   private final MDSequencedMessageWithMarketIDSpecialFields source;
   
   public SpecialField(SpecialFieldValue value, MDSequencedMessageWithMarketIDSpecialFields source) {
      this.value = value;
      this.source = source;
   }

   /**
    * @return the value
    */
   public SpecialFieldValue getValue() {
      return value;
   }

   /**
    * @return the source
    */
   public MDSequencedMessageWithMarketIDSpecialFields getSource() {
      return source;
   }

   public String getKey() {
      if(value.getFieldId() == SpecialFieldValue.ALT_PRICE) {
         if(source instanceof OpenPriceMessage) {
            return getKey(value.getFieldId(), ALT_PRICE_PREFIX_OPEN);
         } else if(source instanceof TradeMessage) {
            return getKey(value.getFieldId(), ALT_LAST_TRADE);
         }
      }

      if(source instanceof MarketSnapshotMessage ) {

         if(value.getFieldId() == SpecialFieldValue.ALT_LAST_TRADE_PRICE)
            return getKey(SpecialFieldValue.ALT_PRICE, ALT_LAST_TRADE);
      }

      return getKey(value.getFieldId());
   }
   
   public static String getKey(byte fieldId) {
      return getKey(fieldId, null);
   }

   public static String getKey(byte fieldId, String prefix) {
      if(null == prefix) {
         prefix = "";
      }
      return prefix + fieldId;
   }
}
