package com.theice.mdf.message;

import com.theice.mdf.message.response.OptionStrategyHedgeDefinition;
import com.theice.mdf.message.response.OptionStrategyLegDefinition;

public class OptionStrategyDefinition
{
   public static final short CONTRACT_SYMBOL_LENGTH = 35;
   private int marketID;
   private int underlyingMarketID;
   private char[] contractSymbol = new char[CONTRACT_SYMBOL_LENGTH];
   private char tradingStatus;
   private char orderPriceDenominator;
   private int incrementPremiumPrice;
   private int incrementQty;
   private int minQty;
   private OptionStrategyLegDefinition[] legDefinitions;
   private OptionStrategyHedgeDefinition[] hedgeDefinitions;
   private short securitySubType;
   private char IsBlockOnly;


   public int getMarketID()
   {
      return marketID;
   }
   public void setMarketID(int marketID)
   {
      this.marketID = marketID;
   }
   public int getUnderlyingMarketID()
   {
      return underlyingMarketID;
   }
   public void setUnderlyingMarketID(int underlyingMarketID)
   {
      this.underlyingMarketID = underlyingMarketID;
   }
   public char[] getContractSymbol()
   {
      return contractSymbol;
   }
   public void setContractSymbol(char[] contractSymbol)
   {
      this.contractSymbol = contractSymbol;
   }
   public char getTradingStatus()
   {
      return tradingStatus;
   }
   public void setTradingStatus(char tradingStatus)
   {
      this.tradingStatus = tradingStatus;
   }
   public char getOrderPriceDenominator()
   {
      return orderPriceDenominator;
   }
   public void setOrderPriceDenominator(char orderPriceDenominator)
   {
      this.orderPriceDenominator = orderPriceDenominator;
   }
   public int getIncrementPremiumPrice()
   {
      return incrementPremiumPrice;
   }
   public void setIncrementPremiumPrice(int incrementPremiumPrice)
   {
      this.incrementPremiumPrice = incrementPremiumPrice;
   }
   public int getIncrementQty()
   {
      return incrementQty;
   }
   public void setIncrementQty(int incrementQty)
   {
      this.incrementQty = incrementQty;
   }
   public int getMinQty()
   {
      return minQty;
   }
   public void setMinQty(int minQty)
   {
      this.minQty = minQty;
   }
   public OptionStrategyLegDefinition[] getLegDefinitions()
   {
      return legDefinitions;
   }
   public void setLegDefinitions(OptionStrategyLegDefinition[] legDefinitions)
   {
      this.legDefinitions = legDefinitions;
   }
   public OptionStrategyHedgeDefinition[] getHedgeDefinitions()
   {
      return hedgeDefinitions;
   }
   public void setHedgeDefinitions(OptionStrategyHedgeDefinition[] hedgeDefinitions)
   {
      this.hedgeDefinitions = hedgeDefinitions;
   }
   
   public int getNumberOfLegDefinitions()
   {
      return legDefinitions ==null? 0 : legDefinitions.length;
   }
     
   public int getNumberOfHedgeDefinitions()
   {
      return hedgeDefinitions ==null? 0 : hedgeDefinitions.length;
   }
   
   public short getSecuritySubType()
   {
   	return securitySubType;
   }
   
   public void setSecuritySubType(short type)
   {
   	securitySubType = type;
   }

   public char getIsBlockOnly() {
      return IsBlockOnly;
   }

   public void setIsBlockOnly(char isBlockOnly) {
      IsBlockOnly = isBlockOnly;
   }
}
