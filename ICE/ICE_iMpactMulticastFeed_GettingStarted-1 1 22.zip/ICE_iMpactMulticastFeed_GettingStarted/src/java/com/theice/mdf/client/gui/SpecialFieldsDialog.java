package com.theice.mdf.client.gui;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.WindowConstants;

import com.theice.mdf.client.domain.MarketInterface;
import com.theice.mdf.client.gui.panel.SpecialFieldsPanel;
import com.theice.mdf.client.gui.panel.SpecialProductDefinitionFieldsPanel;

/**
 * THE CLASSES USED HERE, INCLUDING THE MESSSAGE CLASSES ARE EXAMPLE CODES ONLY.
 * THEY WON'T BE SUPPORTED AS LIBRARY.
 * 
 * Special Fields Dialog - displays Special Fields from Add/Modify Order, Market Statistics,
 * Market Snapshot messages, as well as others
 *
 * @author Barry Fleming
 * Date: Dec 16, 2014
 * Time: 16:04:22
 *
 */
public class SpecialFieldsDialog extends AbstractMDFDialog {
    private static final long serialVersionUID = 1L;
    public static final String CLOSED = "closed";

    protected MarketInterface market = null;

    /**
     * Panel for displaying market statistics
     */
    private final SpecialFieldsPanel specialFieldsPanel;

    private final ActionListener listener;

    /**
     * SpecialFieldsDialog Constructor Make it as a modal dialog
     * 
     * @param frame
     * @param market - used to obtain the bids/offers collections to init the model
     * @param listener 
     */
    public SpecialFieldsDialog(JFrame frame, MarketInterface market, ActionListener listener, boolean isProductDefinition) {
        super(frame);
        this.listener = listener;
        setTitle("Special Fields for "+market.getMarketDesc());

        if(isProductDefinition) {
            specialFieldsPanel = new SpecialProductDefinitionFieldsPanel(market);
        } else {
            specialFieldsPanel = new SpecialFieldsPanel(market);
        }
        getContentPane().add(specialFieldsPanel, BorderLayout.CENTER);
        
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        pack();
        setLocationRelativeTo(frame);
        setVisible(true);
    }
    
    protected void runTimerTask() {
    }

    /**
     * cleanup
     */
    protected synchronized void cleanup() {
        if (specialFieldsPanel != null) {
            specialFieldsPanel.cleanup();
        }
        listener.actionPerformed(new ActionEvent(this, 0, CLOSED));
    }

    public synchronized void refresh() {
        specialFieldsPanel.refresh();
        pack();
    }
}
