package com.theice.mdf.client.multicast.dispatcher;

import org.apache.log4j.Logger;

import com.theice.mdf.client.domain.MarketInterface;
import com.theice.mdf.client.domain.MarketKey;
import com.theice.mdf.client.domain.MarketsHolder;
import com.theice.mdf.client.multicast.handler.NewExpiryMessageHandler;
import com.theice.mdf.client.multicast.handler.NewFlexOptionDefinitionHandler;
import com.theice.mdf.client.multicast.handler.NewFuturesStrategyDefinitionHandler;
import com.theice.mdf.client.multicast.handler.NewOptionStrategyDefinitionHandler;
import com.theice.mdf.client.process.MarketHandlerFactoryInterface;
import com.theice.mdf.message.MDSequencedMessage;
import com.theice.mdf.message.RawMessageFactory;
import com.theice.mdf.message.notification.NewExpiryMessage;
import com.theice.mdf.message.notification.NewFuturesStrategyDefinitionMessage;
import com.theice.mdf.message.notification.NewOptionStrategyDefinitionMessage;
import com.theice.mdf.message.notification.NewOptionsMarketDefinitionMessage;

/**
 * THE CLASSES USED HERE, INCLUDING THE MESSSAGE CLASSES ARE EXAMPLE CODES ONLY.
 * THEY WON'T BE SUPPORTED AS LIBRARY.
 * 
 * @author Adam Athimuthu
 */
public class PriceLevelMulticastDispatcher extends BasicMulticastDispatcher 
{
    static final Logger logger=Logger.getLogger(PriceLevelMulticastDispatcher.class.getName());

    public PriceLevelMulticastDispatcher(String multicastGroupName, MarketHandlerFactoryInterface factory)
    {
    	super(multicastGroupName, factory);
    }

    protected String getName()
    {
    	return("PriceLevelMulticastDispatcher");
    }
    
    /**
     * check validity of message
     * Create the appropriate key based on whether this market is options or not
     * 
     * @param message
     * @return market key
     */
    @Override
    protected MarketKey checkValidityOfMessage(MDSequencedMessage message)
    {
    	MarketInterface market=MarketsHolder.getInstance().findMarket(message.getMarketID());
    	MarketKey key=null;
    	
    	if (market==null)
    	{
    	   if (logger.isDebugEnabled())
    	   {
    	      logger.debug("Market Not found in the cache (PLMulticastDispatcher): "+message.getMarketID());
    	   }
    	   
    	   MarketInterface newMarket = createNewMarketDynamically(message);
           addSequencerForMarket(newMarket);
           key = getMarketKey(newMarket);
    	}
    	else
    	{
    	   key = getMarketKey(market);
    	   if(logger.isTraceEnabled())
    	  	{
    	  	   StringBuffer buf=new StringBuffer("");
    	  	   buf.append("Key : ").append(key.toString());
    	  	   buf.append(" ... for message : ").append(message.toString());
    	  	   logger.trace(buf.toString());
    	  	}
    	}
    	
    	return(key);
    }

    //UDS or Flex Options that are created dynamically
    private MarketInterface createNewMarketDynamically(MDSequencedMessage message) {
        switch (message.getMessageType()) {
            case RawMessageFactory.NewOptionStrategyDefinitionMessageType:
                return NewOptionStrategyDefinitionHandler.getInstance().processNewUDSMarketDefinition((NewOptionStrategyDefinitionMessage) message);
            case RawMessageFactory.NewOptionsMarketDefinitionMessageType:
                return NewFlexOptionDefinitionHandler.getInstance().processNewFlexOptionMarketDefinition((NewOptionsMarketDefinitionMessage) message);
            case RawMessageFactory.NewFuturesStrategyDefinitionMessageType:
                return NewFuturesStrategyDefinitionHandler.getInstance().processNewUDSMarketDefinition((NewFuturesStrategyDefinitionMessage) message);
            case RawMessageFactory.NewExpiryMessageType:
                return NewExpiryMessageHandler.getInstance().processNewExpiryMessage((NewExpiryMessage) message);
        }
        return null;
    }
}

