package com.theice.mdf.client.process;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.theice.logging.domain.ComponentStatus;
import com.theice.mdf.client.ClientState;
import com.theice.mdf.client.config.MDFClientConfigurator;
import com.theice.mdf.client.config.domain.MDFClientConfiguration;
import com.theice.mdf.client.config.domain.MulticastGroupDefinition;
import com.theice.mdf.client.domain.EndPointInfo;
import com.theice.mdf.client.domain.MarketsHolder;
import com.theice.mdf.client.multicast.handler.MarketLoadManager;
import com.theice.mdf.client.process.context.MDFAppContext;
import com.theice.mdf.client.util.MailThrottler;
import com.theice.mdf.message.MessageUtil;
import com.theice.mdf.message.request.DebugRequest;
import com.theice.mdf.message.request.LoginRequest;
import com.theice.mdf.message.request.LogoutRequest;
import com.theice.mdf.message.request.ProductDefinitionRequest;

/**
 * THE CLASSES USED HERE, INCLUDING THE MESSSAGE CLASSES ARE EXAMPLE CODES ONLY.
 * THEY WON'T BE SUPPORTED AS LIBRARY.
 * 
 * @author Adam Athimuthu
 */
public abstract class AbstractMDFClient implements MDFClientInterface
{
   public static final boolean REQUEST_UDS_F = "true".equals(System.getProperty("requestUDSF"));
   public static final boolean REQUEST_UDS_O = "true".equals(System.getProperty("requestUDSO"));
   
   private static Logger logger=Logger.getLogger(AbstractMDFClient.class.getName());
   private static Logger secondaryLogger=Logger.getLogger("com.theice.mdf.client.secondaryLogger");
   private static final long MILLIS_BEFORE_TCP_CONNECTION_FAILURE_ALERT = 1800000; //milliseconds 
   private static final String TCP_CONNECTION_STATUS = "TCPConnection";
   
   private int requestSeqID=0;

   protected Socket clientSoc=null;
   protected Socket endexClientSoc=null;

   protected MarketHandlerFactoryInterface _factory=null;

   private MDFAppContext _context=null;

   private boolean _autoRetry=false;

   public AbstractMDFClient()
   {
      _context=AppManager.getAppContext();
      _autoRetry=AppManager.isAutoReconnectTCP();
   }

   /**
    * Connect to the feed server
    */
   public boolean connect()
   {
      boolean isConnected=false;
      String message="";

      try
      {
         MDFClientConfiguration configuration=MDFClientConfigurator.getInstance().getCurrentConfiguration();

         EndPointInfo tcpEndPoint=configuration.getTcpInfo().getEndPointInfo();
         EndPointInfo endexTcpEndPoint=null;
         if(configuration.getEndexTcpInfo()!=null)
         {
            endexTcpEndPoint = configuration.getEndexTcpInfo().getEndPointInfo();
         }

         // Connect to the feed server
         message="MDFClient: Connecting to feed server - " +tcpEndPoint.getDisplayable();
         logger.info(message);
         _context.logEssential(message);

         clientSoc=new Socket(tcpEndPoint.getIpAddress(),tcpEndPoint.getPort());
         clientSoc.setTcpNoDelay(true);
         
         if(endexTcpEndPoint!=null)
         {
            message="MDFClient: Connecting to Endex feed server - " + endexTcpEndPoint.getDisplayable();
            logger.info(message);
            _context.logEssential(message);

            endexClientSoc=new Socket(endexTcpEndPoint.getIpAddress(), endexTcpEndPoint.getPort());
            endexClientSoc.setTcpNoDelay(true);
         }

         message="MDFClient: Connected to server";
         logger.info(message);
         _context.logEssential(message);

         //if both TCP connections are configured, both need to be connected to be "isConnected = true".
         isConnected=true;
      }
      catch (IOException e)
      {
         message="MDFClient: IOException caught : "+e.toString();
         logger.error(message);
         _context.logEssential(message);
         e.printStackTrace();
         closeConnectionIfNecessary(clientSoc);
         closeConnectionIfNecessary(endexClientSoc);
      }
      catch(Exception e)
      {
         message="MDFClient: Exception caught : "+e.toString();
         logger.error(message);
         _context.logEssential(message);
         e.printStackTrace();
         closeConnectionIfNecessary(clientSoc);
         closeConnectionIfNecessary(endexClientSoc);
      }

      _context.setConnected(isConnected);

      return(isConnected);
   }
   
   private void closeConnectionIfNecessary(Socket socket)
   {
      if(socket!=null)
      {
         try
         {
            socket.close();
         }
         catch(IOException ex)
         {
            logger.error("IOException when closing socket: "+ex, ex);
         }
      }
   }

   /**
    * process
    */
   public void process()
   {
      String logMessage="";

      logger.info("### TCP/IP Socket Thread waiting for start signal ###");

      try
      {
         AppManager.getConsumersReadyLatch().await();
      }
      catch(InterruptedException e)
      {
      }

      short productDefDownloadAttempts=0;
      
      MDFClientConfiguration configuration=MDFClientConfigurator.getInstance().getCurrentConfiguration();

      do
      {   
         logger.info("### TCP/IP Socket Thread Ready to Start ###");

         try
         {
            if (productDefDownloadAttempts++ > 0)
            {
               String errMsg = "ProductDefinitions download failed or not completed, will try again in 45 seconds.";
               logger.info(errMsg);
               MailThrottler.getInstance().enqueueError(errMsg);
               try
               {
                  clientSoc.close();
               }
               catch(IOException e)
               {
                  logger.info("Error when closing socket: "+e, e);
               }
               MarketsHolder.getInstance().clearAllMarkets();
               MarketLoadManager.getInstance().resetMarketLoadStatus();
               Thread.sleep(45000);
            }

            openTcpConnection_KeepTryingIfNeeded();

            InputStream inStream = clientSoc.getInputStream();
            InputStream endexInStream = null;
            OutputStream endexOutStream = null;
            MDFClientSocketReader endexReader = null;
            Thread endexReaderThread = null;
            Thread endexConsumerThread = null;

            // Start socket reader thread for processing response/streamed data from server
            MDFClientSocketReader reader = new MDFClientSocketReader(new DataInputStream(inStream));
            Thread readerThread = new Thread(reader, "ReaderThread");
            readerThread.start();

            // Start message consumer thread for processing messages
            Thread consumerThread = new Thread(createMessageConsumer(reader), "ConsumerThread");
            consumerThread.start();

            OutputStream outStream = clientSoc.getOutputStream();
            
            if(endexClientSoc!=null)
            {
               endexInStream = endexClientSoc.getInputStream();
               endexReader = new MDFClientSocketReader(new DataInputStream(endexInStream));
               endexReaderThread = new Thread(endexReader, "EndexReaderThread");
               endexReaderThread.start();
               endexConsumerThread = new Thread(createMessageConsumer(endexReader), "EndexConsumerThread");
               endexConsumerThread.start();
               endexOutStream = endexClientSoc.getOutputStream();
            }

            // send debug request
            logMessage="MDFClient: send debug request";
            logger.info(logMessage);
            _context.logEssential(logMessage);
            sendDebugRequest(outStream);

            // send login request
            logMessage="MDFClient: send login request";
            logger.info(logMessage);
            _context.logEssential(logMessage);
            login(outStream, configuration.getTcpInfo().getUserName(), configuration.getTcpInfo().getPassword());
            
            if(endexOutStream!=null)
            {
               login(endexOutStream, configuration.getEndexTcpInfo().getUserName(), configuration.getEndexTcpInfo().getPassword());
            }

            // send product definition requests
            logMessage="MDFClient: send product definition requests";
            logger.info(logMessage);
            _context.logEssential(logMessage);
            
            //if there is a Endex TCP connection, we will ignore Endex market types in the regular TCP connection
            //and let the Endex TCP connection take care of the Endex product definition requests.
            requestProductDefinitions(outStream, (endexOutStream!=null));
            if(endexOutStream!=null)
            {
               requestEndexProductDefinitions(endexOutStream);
            }
            //wait for reader and consumer threads
            //consumerThread, upon receiving product definitions, will updateLoadStatus from MarketLoadManager
            //if all product definitions are loaded, it will then close the socket connection
            readerThread.join();
            consumerThread.join();
            if(endexReaderThread!=null)
            {
               endexReaderThread.join();
            }
            if(endexConsumerThread!=null)
            {
               endexConsumerThread.join();
            }
            
         }
         catch(IOException e)
         {
            logMessage="MDFClient: IOException caught : "+e.toString();
            _context.logEssential(logMessage);
            logger.error(logMessage);
            e.printStackTrace();
         }
         catch(InterruptedException e)
         {
            logMessage="MDFClient: InterruptedException caught : "+e.toString();
            logger.error(logMessage);
            _context.logEssential(logMessage);
            e.printStackTrace();
         }
      } 
      while(MarketLoadManager.getInstance().getLoadingStatus() != MarketLoadManager.LOAD_COMPLETED);

      logMessage="MDFClient: Exiting...";
      logger.error(logMessage);
      _context.logEssential(logMessage);

   }

   private void openTcpConnection_KeepTryingIfNeeded()
   {
      boolean hasRaisedTcpConnectionError = false;
      long sleepTimeIncrementInMillis = 5*60*1000;
      long sleepTimeInMillis = 30000;
      int extendedConnectionFailedAttempts=0;
      long tcpConnectionWarningThreshold = MILLIS_BEFORE_TCP_CONNECTION_FAILURE_ALERT;
      String tcpConnectionWarningThresholdProperty = System.getProperty("tcpConnectionWarningThreshold");
      if (tcpConnectionWarningThresholdProperty!=null && tcpConnectionWarningThresholdProperty.length()>0)
      {
         try
         {
            tcpConnectionWarningThreshold = Long.parseLong(tcpConnectionWarningThresholdProperty);
         }
         catch(Exception ex)
         {
            logger.error("Error getting tcp connection warning threshold, use default. "+ex, ex);
         }
      }
      MDFClientConfiguration configuration=MDFClientConfigurator.getInstance().getCurrentConfiguration();
      EndPointInfo tcpEndPoint=configuration.getTcpInfo().getEndPointInfo();
      ClientState clientState = new ClientState("MCFeedClient", "MCFeedClient", "MCFeedClient", tcpEndPoint.getIpAddress()+":"+tcpEndPoint.getPort());
      clientState.setComponentStatus(ComponentStatus.UP);
      
      long startTime = System.currentTimeMillis();
      
      do
      {
         if (connect()==false)
         {
            String logMessage="Failed to connect to the feed server.";
            logger.error(logMessage);
            _context.logEssential(logMessage);
            _context.alert(logMessage);

            if (!_autoRetry)
            {
               return;
            }
            else
            {
               if (System.currentTimeMillis() - startTime >= tcpConnectionWarningThreshold)
               {
                  //TCP login has been failing for over 30 mins, raise an alert
                  String errorMsg = "Failing to connect to the feed server for extended period of time. Please check connection. Client will keep trying.";
                  MailThrottler.getInstance().enqueueError(errorMsg);
                  secondaryLogger.error(errorMsg);
                  if (!hasRaisedTcpConnectionError)
                  {
                     AppManager.sendAlert(TCP_CONNECTION_STATUS, "MulticastCient", errorMsg, AppManager.TCP_CONNECTION_ERROR_CODE, clientState);
                     hasRaisedTcpConnectionError = true;
                  }
                  //most likely this is an extended outage, let's sleep longer
                  sleepTimeInMillis = 10*60*1000 + extendedConnectionFailedAttempts++*sleepTimeIncrementInMillis;
               }
               try
               {
                  logger.info("Sleep before next TCP connection attempt, sleep time in millis: "+sleepTimeInMillis);
                  Thread.sleep(sleepTimeInMillis);
               }
               catch(Exception ex)
               {
                  logger.error("Exception happened when sleeping:"+ex);
               }
            }
         }
      }
      while(_autoRetry && _context.isConnected()==false);

      if (hasRaisedTcpConnectionError)
      {
         //clear the error
         AppManager.sendAlert(TCP_CONNECTION_STATUS, "MulticastClient", "Cleared", AppManager.CLEARED, clientState);
      }
   }
   
   /**
    * Send a debug request
    * @param outStream
    * @throws java.io.IOException
    */
   private void sendDebugRequest(OutputStream outStream) throws IOException
   {
      DebugRequest debugRequest = new DebugRequest();
      debugRequest.RequestSeqID = getRequestSeqID();
      outStream.write(debugRequest.serialize());
   }

   /**
    * Send login request
    *
    * @param outStream
    * @throws java.io.IOException
    */
   protected void login(OutputStream outStream, String userName, String password) throws IOException
   {
      LoginRequest loginRequest = createLoginRequest(userName, password);
      outStream.write(loginRequest.serialize());
   }

   /**
    * Request for the product defintions of the market types that we are interested in
    * @param outStream
    * @param securityType (Futures or Options)
    * @throws java.io.IOException
    */
   protected void requestProductDefinitions(OutputStream outStream, boolean excludeEndexMarketTypes) throws IOException
   {
      MDFClientConfiguration configuration=MDFClientConfigurator.getInstance().getCurrentConfiguration();
      List<Short> endexMarketTypes = configuration.getMDFClientRuntimeParameters().getEndexMarketTypeIDs();
      
      List<String> interestedMulticastGroupNames = configuration.getInterestedMulticastGroupNames();
      Map<String, MulticastGroupDefinition> multicastGroupDefinitionMap = configuration.getMulticastGroupDefinitionMap();

      ArrayList<Short> allInterestedMarketTypeCodesForFutures = new ArrayList<Short>();
      ArrayList<Short> allInterestedMarketTypeCodesForOptions = new ArrayList<Short>();
      ArrayList<Short> allInterestedMarketTypeCodesForFuturesExcludeEndex = new ArrayList<Short>();

      for(String multicastGroupName:interestedMulticastGroupNames)
      {
         MulticastGroupDefinition groupDefinition = multicastGroupDefinitionMap.get(multicastGroupName);
         short[] marketTypeCodes = configuration.getInterestedMarketTypeCodes(multicastGroupName);
         for(int i=0; i<marketTypeCodes.length; i++)
         {
            allInterestedMarketTypeCodesForFutures.add(marketTypeCodes[i]);
            if (groupDefinition.isOptions())
            {
               allInterestedMarketTypeCodesForOptions.add(marketTypeCodes[i]);
            }
         }
      }

      List<ProductDefinitionRequest> requests=new ArrayList<ProductDefinitionRequest>();

      for(Short marketTypeCode:allInterestedMarketTypeCodesForFutures)
      {
         if(excludeEndexMarketTypes && endexMarketTypes!=null && endexMarketTypes.contains(marketTypeCode))
         {
            //exclude endex market types here when they will be requested thru the Endex TCP connection
            continue;
         }
         
         allInterestedMarketTypeCodesForFuturesExcludeEndex.add(marketTypeCode);
         ProductDefinitionRequest pdRequest = new ProductDefinitionRequest();
         pdRequest.MarketType=marketTypeCode;
         pdRequest.RequestSeqID=getRequestSeqID();
         pdRequest.SecurityType=ProductDefinitionRequest.SECURITY_TYPE_FUTRES_OTC;

         /**
          * Register with the load manager for tracking
          * If a market type already exists, just overlay so we don't send a duplicate request
          */
         if(MarketLoadManager.getInstance().registerLoadRequest(pdRequest))
         {
            requests.add(pdRequest);
         }
         else
         {
            logger.warn("Avoid duplicate Product Definition Request for : "+pdRequest.MarketType);
         }
      }

      for(Iterator<ProductDefinitionRequest> it=requests.iterator();it.hasNext();)
      {
         ProductDefinitionRequest request=it.next();
         outStream.write(request.serialize());
      }

      //request for options product definitions if needed
      requests = new ArrayList<ProductDefinitionRequest>();
      for(Short marketTypeCode:allInterestedMarketTypeCodesForOptions)
      {
         ProductDefinitionRequest pdRequest = new ProductDefinitionRequest();
         pdRequest.MarketType=marketTypeCode;
         pdRequest.RequestSeqID=getRequestSeqID();
         pdRequest.SecurityType=ProductDefinitionRequest.SECURITY_TYPE_OPTION;

         /**
          * Register with the load manager for tracking
          * If a market type already exists, just overlay so we don't send a duplicate request
          */
         if(MarketLoadManager.getInstance().registerLoadRequest(pdRequest))
         {
            requests.add(pdRequest);
         }
         else
         {
            logger.warn("Avoid duplicate Product Definition Request for : "+pdRequest.MarketType);
         }
      }

      for(Iterator<ProductDefinitionRequest> it=requests.iterator();it.hasNext();)
      {
         ProductDefinitionRequest request=it.next();
         outStream.write(request.serialize());
      }

      //request UDS market definitions if needed
      requestUDSDefinitionsIfNeeded(outStream, configuration,
            interestedMulticastGroupNames,
            allInterestedMarketTypeCodesForFutures,
            allInterestedMarketTypeCodesForOptions,
            allInterestedMarketTypeCodesForFuturesExcludeEndex);

   }

   protected void requestUDSDefinitionsIfNeeded(OutputStream outStream,
         MDFClientConfiguration configuration,
         List<String> interestedMulticastGroupNames,
         ArrayList<Short> allInterestedMarketTypeCodesForFutures,
         ArrayList<Short> allInterestedMarketTypeCodesForOptions,
         ArrayList<Short> allInterestedMarketTypeCodesForFuturesExcludeEndex)
         throws IOException
   {
      List<ProductDefinitionRequest> udsRequests = null;
      
      if (configuration.isInterestedInUDS() && interestedMulticastGroupNames.size()==1)
      {
         //This is for GUI mode
         if(interestedMulticastGroupNames.get(0).contains(MDFClientConfigurator.MULTICAST_GROUP_NAME_OPTIONS_KEY_WORD))
         {
            udsRequests = getUDSProductDefinitionRequestList(allInterestedMarketTypeCodesForOptions, true);
         }
         else
         {
            udsRequests = getUDSProductDefinitionRequestList(allInterestedMarketTypeCodesForFutures, false);
         }
      }
      else
      {
         //Command line mode
         if(REQUEST_UDS_F)
         {
            udsRequests = getUDSProductDefinitionRequestList(allInterestedMarketTypeCodesForFuturesExcludeEndex, false);
         }
         if(REQUEST_UDS_O)
         {
            List<ProductDefinitionRequest> optionsUDSReqs = getUDSProductDefinitionRequestList(allInterestedMarketTypeCodesForOptions, true);
            if(udsRequests==null)
            {
               udsRequests = optionsUDSReqs;
            }
            else if(optionsUDSReqs!=null)
            {
               udsRequests.addAll(optionsUDSReqs);
            }
         }
      }
      
      if(udsRequests!=null)
      {
         for(Iterator<ProductDefinitionRequest> it=udsRequests.iterator();it.hasNext();)
         {
            ProductDefinitionRequest request=it.next();
            outStream.write(request.serialize());
         }         
      }
   }
   
   protected ArrayList<ProductDefinitionRequest> getUDSProductDefinitionRequestList(ArrayList<Short> marketTypeList, boolean isOptions)
   {
      ArrayList<ProductDefinitionRequest> udsRequests = new ArrayList<ProductDefinitionRequest>();
      for(Short marketTypeCode:marketTypeList)
      {
         ProductDefinitionRequest pdRequest = new ProductDefinitionRequest();
         pdRequest.MarketType=marketTypeCode;
         pdRequest.RequestSeqID=getRequestSeqID();
         pdRequest.SecurityType = isOptions? ProductDefinitionRequest.SECURITY_TYPE_UDS_OPTIONS : ProductDefinitionRequest.SECURITY_TYPE_UDS_FUTURES;

         /**
          * Register with the load manager for tracking
          * If a market type already exists, just overlay so we don't send a duplicate request
          */
         if(MarketLoadManager.getInstance().registerLoadRequest(pdRequest))
         {
            udsRequests.add(pdRequest);
         }
         else
         {
            logger.warn("Avoid duplicate UDS Product Definition Request for : "+pdRequest.MarketType+", securityType="+pdRequest.SecurityType);
         }
      }
      
      return udsRequests;
   }
   
   protected void requestEndexProductDefinitions(OutputStream outStream) throws IOException
   {       
      MDFClientConfiguration configuration=MDFClientConfigurator.getInstance().getCurrentConfiguration();
      List<Short> endexMarketTypes = configuration.getMDFClientRuntimeParameters().getEndexMarketTypeIDs();
      if(endexMarketTypes==null || endexMarketTypes.size()==0)
      {
         logger.error("No Endex market type found in config parameters.");
         return;
      }

      List<ProductDefinitionRequest> requests=new ArrayList<ProductDefinitionRequest>();

      for(Short endexMarketTypeCode:endexMarketTypes)
      {
         ProductDefinitionRequest pdRequest = new ProductDefinitionRequest();
         pdRequest.MarketType=endexMarketTypeCode;
         pdRequest.RequestSeqID=getRequestSeqID();
         pdRequest.SecurityType=ProductDefinitionRequest.SECURITY_TYPE_FUTRES_OTC;

         /**
          * Register with the load manager for tracking
          * If a market type already exists, just overlay so we don't send a duplicate request
          */
         if(MarketLoadManager.getInstance().registerLoadRequest(pdRequest))
         {
            requests.add(pdRequest);
         }
         else
         {
            logger.warn("Avoid duplicate Product Definition Request for : "+pdRequest.MarketType);
         }
      }

      for(Iterator<ProductDefinitionRequest> it=requests.iterator();it.hasNext();)
      {
         ProductDefinitionRequest request=it.next();
         outStream.write(request.serialize());
      }
   }

   /**
    * Increment and return the request sequence ID
    * @return the request sequence ID
    */
   protected int getRequestSeqID()
   {
      return(requestSeqID++);
   }

   /**
    * Create Base Login Request
    * @return
    */
   protected LoginRequest createBaseLoginRequest(String userName, String password)
   {
      LoginRequest loginRequest = new LoginRequest();

      MDFClientConfiguration configuration=MDFClientConfigurator.getInstance().getCurrentConfiguration();

      loginRequest.UserName
      = MessageUtil.toRawChars(userName,loginRequest.UserName.length);
      loginRequest.Password
      = MessageUtil.toRawChars(password,loginRequest.Password.length);
      
      loginRequest.RequestSeqID=getRequestSeqID();

      if (configuration.getMDFClientRuntimeParameters().isGetStripInfo())
      {
         loginRequest.GetStripInfoMessages = 'Y';
      }

      //ReservedField1 is currently not used. Reserved for future use.
      if (System.getProperty("ReservedField1")!=null)
      {
         try
         {
            short reservedField1 = Short.parseShort(System.getProperty("ReservedField1"));
            loginRequest.ReservedField1 = reservedField1;
         }
         catch(Exception ex)
         {
         }
      }

      return(loginRequest);
   }

   /**
    * Return the factory associated with this client
    * @return factory
    */
   public MarketHandlerFactoryInterface getFactory()
   {
      return(_factory);
   }

   protected void requestLogout(OutputStream outStream) throws IOException
   {
      LogoutRequest logoutReq = new LogoutRequest();
      logoutReq.RequestSeqID = getRequestSeqID();
      outStream.write(logoutReq.serialize());
   }

   public void logoutAndCloseSocket() 
   {
      try
      {
         logger.info("*** TCP Socket is no longer needed. Log out and close it...");
         logger.info("*** Sending logout request...");
         requestLogout(clientSoc.getOutputStream());
         logger.info("*** Closing socket...");
         clientSoc.close();
         
         if(endexClientSoc!=null)
         {
            requestLogout(endexClientSoc.getOutputStream());
            endexClientSoc.close();
         }
         
         AppManager.stopInactivityTimer();
      } 
      catch(Exception ex)
      {
         String errMsg="logoutAndCloseSocket(): Exception caught : "+ex.toString();
         logger.error(errMsg, ex);
      }
   }

   /**
    * Template Methods
    */
   protected abstract LoginRequest createLoginRequest(String userName, String password);

   protected abstract Runnable createMessageConsumer(MDFClientSocketReader reader);
}
