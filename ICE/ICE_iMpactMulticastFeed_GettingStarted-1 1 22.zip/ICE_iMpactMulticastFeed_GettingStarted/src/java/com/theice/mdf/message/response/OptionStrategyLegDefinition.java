package com.theice.mdf.message.response;

import java.nio.ByteBuffer;

public class OptionStrategyLegDefinition
{
   public static final byte MESSAGE_LENGTH = 12;
  
   public int LegMarketID;
   public int LegUnderlyingMarketID;
   public short LegRatio;
   public char LegSide;
   private byte _actualMessageLength = MESSAGE_LENGTH;
   
   public void serialize(ByteBuffer serializedContent)
   {
      if (serializedContent != null)
      {
         serializedContent.put(MESSAGE_LENGTH);
         serializedContent.putInt(LegMarketID);
         serializedContent.putInt(LegUnderlyingMarketID);
         serializedContent.putShort(LegRatio);
         serializedContent.put((byte)LegSide);
      }
   }
   
   public void deserialize( ByteBuffer inboundcontent )
   {
      _actualMessageLength = inboundcontent.get();
      LegMarketID = inboundcontent.getInt();
      LegUnderlyingMarketID = inboundcontent.getInt();
      LegRatio = inboundcontent.getShort();
      LegSide = (char)inboundcontent.get();
   }
   
   public byte getActualMessageLength()
   {
      return _actualMessageLength;
   }
   
   public String toString()
   {
      //noinspection StringBufferReplaceableByString
      StringBuilder strBuilder = new StringBuilder("OptionStrategyLegDefinition|MessageLength=");
      strBuilder.append(_actualMessageLength);
      strBuilder.append("|LegMarketID=");
      strBuilder.append(LegMarketID);
      strBuilder.append("|LegUnderlyingMarketID=");
      strBuilder.append(LegUnderlyingMarketID);
      strBuilder.append("|LegRatio=");
      strBuilder.append(LegRatio);
      strBuilder.append("|LegSide=");
      strBuilder.append(LegSide);
      strBuilder.append("|");
      
      return strBuilder.toString();
   }

   @Override
   public boolean equals(Object o) {
      if (this == o) return true;
      if (!(o instanceof OptionStrategyLegDefinition)) return false;

      OptionStrategyLegDefinition that = (OptionStrategyLegDefinition) o;

      if (LegMarketID != that.LegMarketID) return false;
      if (LegRatio != that.LegRatio) return false;
      if (LegSide != that.LegSide) return false;
      if (LegUnderlyingMarketID != that.LegUnderlyingMarketID) return false;
      if (_actualMessageLength != that._actualMessageLength) return false;

      return true;
   }

   @Override
   public int hashCode() {
      int result = LegMarketID;
      result = 31 * result + LegUnderlyingMarketID;
      result = 31 * result + (int) LegRatio;
      result = 31 * result + (int) LegSide;
      result = 31 * result + (int) _actualMessageLength;
      return result;
   }
}
