package com.theice.mdf.client.gui.listeners;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JTable;

import com.theice.mdf.client.config.MDFClientConfigurator;
import com.theice.mdf.client.config.domain.MDFClientConfiguration;
import com.theice.mdf.client.domain.Market;
import com.theice.mdf.client.domain.MarketKey;
import com.theice.mdf.client.exception.InvalidStateException;
import com.theice.mdf.client.gui.AbstractMDFDialog;
import com.theice.mdf.client.gui.BookDialog;
import com.theice.mdf.client.gui.DependentMarketsDialog;
import com.theice.mdf.client.gui.MDFClientFrame;
import com.theice.mdf.client.gui.panel.SpecialFieldsDialogManager;
import com.theice.mdf.client.gui.table.MarketTableColumn;
import com.theice.mdf.client.gui.table.MarketTableModel;
import com.theice.mdf.client.process.MDFClientContext;

/**
 * THE CLASSES USED HERE, INCLUDING THE MESSSAGE CLASSES ARE EXAMPLE CODES ONLY.
 * THEY WON'T BE SUPPORTED AS LIBRARY.
 * 
 * Handles the selection from the underlying market
 *
 * @author Adam Athimuthu
 * Date: Aug 9, 2007
 * Time: 9:34:30 AM
 */
public class MarketTableMouseAdapter extends MouseAdapter
{
    private final SpecialFieldsDialogManager specialFieldsDialogManager;

    /**
     * @param marketsTable
     */
    public MarketTableMouseAdapter(SpecialFieldsDialogManager specialFieldsDialogManager) {
        this.specialFieldsDialogManager = specialFieldsDialogManager;
    }

    /**
     * Handle double click on the table
     * 
     * There are two possible flows:
     * 
     * 1. If the current multicast group is set to "options", then we will show the dependent (options) markets
     * 2. Otherwise, show the book dialog associated with the underlying markets
     * 
     * @param event
     */
    public void mouseClicked(MouseEvent event)
    {
        JTable target = (JTable) event.getSource();
        int row = target.getSelectedRow();
        int column = target.getSelectedColumn();
        if (row < 0 || column < 0) {
            return;
        }
        MarketTableModel model = (MarketTableModel) target.getModel();

        boolean handleSpecialFields = false;
        if(column == MarketTableColumn.COLID_SPECIALFIELDS)
        {
            handleSpecialFields = handleSpecialFields(model, row, column);
        }

        if(event.getClickCount() == 2 && false == handleSpecialFields)
        {
            Market market=(Market) model.getMarkets().get(row);
            
            MDFClientConfiguration configuration=MDFClientConfigurator.getInstance().getCurrentConfiguration();
            
            MarketKey marketKey = market.getMarketKey();
            
            AbstractMDFDialog dialog = AbstractMDFDialog.getBookDialogWindow(marketKey);
            
            if (dialog==null)
            {
               if(configuration.getMulticastGroupDefinition(MDFClientContext.getInstance().getInterestedMulticastGroupNames().get(0)).isOptions())
               {
                  try
                  {
                     AbstractMDFDialog.addBookToTrackingMap(marketKey,new DependentMarketsDialog(MDFClientFrame.getInstance(),market));
                  }
                  catch(InvalidStateException e)
                  {
                     e.printStackTrace();
                     System.err.println("Failed to launch the DependentMarketsDialog : "+e.toString());
                  }
               }
               else
               {
                  AbstractMDFDialog.addBookToTrackingMap(marketKey,new BookDialog(MDFClientFrame.getInstance(),market));
               }
            }
            else //dialog window already exists
            {
               dialog.setVisible(true);
            }
        }

        return;
    }

    private synchronized boolean handleSpecialFields(MarketTableModel model, int row, int column) {
        if (false == "N/A".equals(String.valueOf(model.getValueAt(row, column)))) {
            Market market = (Market) model.getMarkets().get(row);
            specialFieldsDialogManager.openSpecialFieldsDialog(market, true);
            return true;
        }
        return false;
    }
}
