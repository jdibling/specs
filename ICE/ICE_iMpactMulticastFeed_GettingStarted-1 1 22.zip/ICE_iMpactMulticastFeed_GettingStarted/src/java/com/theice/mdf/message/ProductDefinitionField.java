package com.theice.mdf.message;

import java.nio.ByteBuffer;

/**
 * User: dkim
 * Date: 12/10/14
 * Time: 12:53 PM
 */
public class ProductDefinitionField {

   // Field Ids
   public static final short FIELD_ALT_PRICE_DENOMINATOR = 1;
   public static final short FIELD_COUPON_RATE = 2;
   public static final short FIELD_COUPON_RATE_DENOMINATOR = 3;
   public static final short FIELD_DATED_DATE = 4;
   public static final short FIELD_INTEREST_ACCRUAL_DATE = 5;
   public static final short FIELD_ISSUE_DATE = 6;
   public static final short FIELD_REPURCHASE_RATE = 7;
   public static final short FIELD_REPURCHASE_DATE = 8;
   public static final short FIELD_FACTOR = 9;
   public static final short FIELD_INTERPOLATION_FACTOR = 10;
   public static final short FIELD_INTERPOLATION_FACTOR_DENOMINATOR = 11;
   public static final short FIELD_INSTR_REGISTY = 12;
   public static final short FIELD_CREDIT_RATING = 13;
   public static final short FIELD_ACCRUED_PREMIUM_AMT = 14;
   public static final short FIELD_EVENT_PAYMENT_AMT = 15;
   public static final short FIELD_ALIGNMENT_INTEREST_RATE = 16;
   public static final short FIELD_SETTLEMENT_TYPE = 17;
   public static final short FIELD_IS_BLOCK_ONLY = 18;
   public static final short FIELD_FLEX_ALLOWED = 19;
   public static final short FIELD_HEDGE_MARKET_ID = 20;
   public static final short FIELD_UNKNOWN = Short.MAX_VALUE;

   public static final short FIELD_UNKNOWN_LENGTH = 190;
   public static final char[] FIELD_UNKNOWN_VALUE = MessageUtil.toRawChars(
           "This is an unknown test field that is only sent out in test env. Per iMpact spec, "+
           "client is required to handle it, by reading the right number of bytes based on the field length value.", FIELD_UNKNOWN_LENGTH);

   public static final short REPURCHASE_RATE_DENOMINATOR = 5;
   public static final short FACTOR_DENOMINATOR = 2;
   public static final short CONTRACT_MULTIPLIER_DENOMINATOR = 0;
   public static final short ACCRUED_PREMIUM_AMT_DENOMINATOR = 10;
   public static final short EVENT_PAYMENT_AMT_DENOMINATOR = 10;
   public static final short ALIGNMENT_INTEREST_RATE_DENOMINATOR = 10;


   public static final String FIELD_NAME_ALT_PRICE_DENOMINATOR = "AltPriceDenominator";
   public static final String FIELD_NAME_COUPON_RATE = "CouponRate";
   public static final String FIELD_NAME_COUPON_RATE_DENOMINATOR = "CouponRateDenominator";
   public static final String FIELD_NAME_DATED_DATE = "DatedDate";
   public static final String FIELD_NAME_INTEREST_ACCRUAL_DATE = "InterestAccrualDate";
   public static final String FIELD_NAME_ISSUE_DATE = "IssueDate";
   public static final String FIELD_NAME_REPURCHASE_RATE = "RepurchaseRate";
   public static final String FIELD_NAME_REPURCHASE_DATE = "RepurchaseDate";
   public static final String FIELD_NAME_FACTOR = "Factor";
   public static final String FIELD_NAME_INTERPOLATION_FACTOR = "InterpolationFactor";
   public static final String FIELD_NAME_INTERPOLATION_FACTOR_DENOMINATOR = "InterpolationFactorDenom";
   public static final String FIELD_NAME_INSTR_REGISTRY = "InstrRegistry";
   public static final String FIELD_NAME_CREDIT_RATING = "CreditRating";
   public static final String FIELD_NAME_ACCRUED_PREMIUM_AMT = "AccruedPremiumAmt";
   public static final String FIELD_NAME_EVENT_PAYMENT_AMT = "EventPaymentAmt";
   public static final String FIELD_NAME_ALIGNMENT_INTEREST_RATE = "AlignmentInterestRate";
   public static final String FIELD_NAME_SETTLEMENT_TYPE = "SettlementType";
   public static final String FIELD_NAME_IS_BLOCK_ONLY = "IsBlockOnly";
   public static final String FIELD_NAME_FLEX_ALLOWED = "FlexAllowed";
   public static final String FIELD_NAME_HEDGE_MARKET_ID = "HedgeMarketId";

   protected short fieldId;
   protected Object value;

   public short getFieldId() {
      return fieldId;
   }

   public Object getValue() {
      return value;
   }
   public String getValueAsString() {
      if ( value instanceof char[])
         return MessageUtil.toString((char[])value);
      return String.valueOf(value);
   }

   public ProductDefinitionField(short fieldId, Object value) {
      this.fieldId = fieldId;
      this.value = value;
   }

   public ProductDefinitionField(ByteBuffer inbound) {
      fieldId = inbound.getShort();
      short length = inbound.getShort();
      switch (fieldId) {
         case FIELD_ALT_PRICE_DENOMINATOR:
         case FIELD_INTERPOLATION_FACTOR_DENOMINATOR:
         case FIELD_COUPON_RATE_DENOMINATOR:
            value = (short) inbound.get();
            break;
         case FIELD_INSTR_REGISTY:
            char[] instrRegistry = new char[2];
            for( int i=0; i<instrRegistry.length; i++ )
            {
               instrRegistry[i] = (char)inbound.get();
            }
            value = instrRegistry;
            break;
         case FIELD_CREDIT_RATING:
            char[] creditRating = new char[8];
            for( int i=0; i<creditRating.length; i++ )
            {
               creditRating[i] = (char)inbound.get();
            }
            value = creditRating;
            break;
         case FIELD_COUPON_RATE:
         case FIELD_DATED_DATE:
         case FIELD_INTEREST_ACCRUAL_DATE:
         case FIELD_ISSUE_DATE:
         case FIELD_REPURCHASE_DATE:
         case FIELD_REPURCHASE_RATE:
         case FIELD_INTERPOLATION_FACTOR:
         case FIELD_FACTOR:
         case FIELD_ACCRUED_PREMIUM_AMT:
         case FIELD_EVENT_PAYMENT_AMT:
         case FIELD_ALIGNMENT_INTEREST_RATE:
            value = inbound.getLong();
            break;
         case FIELD_UNKNOWN:
            char[] charArray = new char[length];
            for( int i=0; i<charArray.length; i++ )
            {
               charArray[i] = (char)inbound.get();
            }
            value = charArray;
            break;
         case FIELD_SETTLEMENT_TYPE:
         case FIELD_IS_BLOCK_ONLY:
         case FIELD_FLEX_ALLOWED:
            value = (char) inbound.get();
            break;
         case FIELD_HEDGE_MARKET_ID:
            value = inbound.getInt();
            break;
         default:
            value = new byte[length];
            inbound.get((byte[]) value);
            break;
      }
   }

   public short getLength() {
      return getFieldLength(fieldId);
   }

   public static short getFieldLength(short fieldId) {

      switch (fieldId) {
         case FIELD_ALT_PRICE_DENOMINATOR:
         case FIELD_COUPON_RATE_DENOMINATOR:
         case FIELD_INTERPOLATION_FACTOR_DENOMINATOR:
         case FIELD_SETTLEMENT_TYPE:
         case FIELD_IS_BLOCK_ONLY:
         case FIELD_FLEX_ALLOWED:
            return 1;
         case FIELD_INSTR_REGISTY:
            return 2;
         case FIELD_HEDGE_MARKET_ID:
            return 4;
         case FIELD_COUPON_RATE:
         case FIELD_DATED_DATE:
         case FIELD_INTEREST_ACCRUAL_DATE:
         case FIELD_ISSUE_DATE:
         case FIELD_REPURCHASE_DATE:
         case FIELD_INTERPOLATION_FACTOR:
         case FIELD_CREDIT_RATING:
         case FIELD_REPURCHASE_RATE:
         case FIELD_FACTOR:
         case FIELD_ACCRUED_PREMIUM_AMT:
         case FIELD_EVENT_PAYMENT_AMT:
         case FIELD_ALIGNMENT_INTEREST_RATE:
            return 8;
         case FIELD_UNKNOWN:
            return FIELD_UNKNOWN_LENGTH;
         default:
            throw new UnsupportedOperationException("Error");
      }
   }


   public void putValue(ByteBuffer serializedContent) {
      switch (fieldId) {

         case FIELD_ALT_PRICE_DENOMINATOR:
         case FIELD_COUPON_RATE_DENOMINATOR:
         case FIELD_INTERPOLATION_FACTOR_DENOMINATOR:
            serializedContent.put((byte) ((Short) value).shortValue());
            return;
         case FIELD_INSTR_REGISTY:
            char[] instrRegistry = (char[]) value;
            for( int i=0; i<instrRegistry.length ; i++ )
            {
               serializedContent.put( (byte)instrRegistry[i] );
            }
            return ;
         case FIELD_CREDIT_RATING:
            char[] creditRating = (char[]) value;
            for( int i=0; i<creditRating.length ; i++ )
            {
               serializedContent.put( (byte)creditRating[i] );
            }
            return ;
         case FIELD_COUPON_RATE:
         case FIELD_DATED_DATE:
         case FIELD_INTEREST_ACCRUAL_DATE:
         case FIELD_ISSUE_DATE:
         case FIELD_REPURCHASE_DATE:
         case FIELD_INTERPOLATION_FACTOR:
         case FIELD_REPURCHASE_RATE:
         case FIELD_FACTOR:
         case FIELD_ACCRUED_PREMIUM_AMT:
         case FIELD_EVENT_PAYMENT_AMT:
         case FIELD_ALIGNMENT_INTEREST_RATE:
            serializedContent.putLong((Long) value);
            return;
         case FIELD_HEDGE_MARKET_ID:
            serializedContent.putInt((Integer) value);
            return;
         case FIELD_SETTLEMENT_TYPE:
         case FIELD_IS_BLOCK_ONLY:
         case FIELD_FLEX_ALLOWED:
            serializedContent.put((byte) ((Character) value).charValue());
            return;
         case FIELD_UNKNOWN:
            char[] charArray = (char[])value;
            for( int i=0; i<charArray.length; i++ )
               serializedContent.put((byte)charArray[i]);
            return;
         default:
            throw new UnsupportedOperationException("Error");
      }
   }

   public String getFieldName() {
      switch (fieldId) {
         case FIELD_ALT_PRICE_DENOMINATOR:
            return FIELD_NAME_ALT_PRICE_DENOMINATOR;
         case FIELD_COUPON_RATE:
            return FIELD_NAME_COUPON_RATE;
         case FIELD_COUPON_RATE_DENOMINATOR:
            return FIELD_NAME_COUPON_RATE_DENOMINATOR;
         case FIELD_DATED_DATE:
            return FIELD_NAME_DATED_DATE;
         case FIELD_INTEREST_ACCRUAL_DATE:
            return FIELD_NAME_INTEREST_ACCRUAL_DATE;
         case FIELD_ISSUE_DATE:
            return FIELD_NAME_ISSUE_DATE;
         case FIELD_REPURCHASE_RATE:
            return FIELD_NAME_REPURCHASE_RATE;
         case FIELD_REPURCHASE_DATE:
            return FIELD_NAME_REPURCHASE_DATE;
         case FIELD_FACTOR:
            return FIELD_NAME_FACTOR;
         case FIELD_INTERPOLATION_FACTOR:
            return FIELD_NAME_INTERPOLATION_FACTOR;
         case FIELD_INTERPOLATION_FACTOR_DENOMINATOR:
            return FIELD_NAME_INTERPOLATION_FACTOR_DENOMINATOR;
         case FIELD_INSTR_REGISTY:
            return FIELD_NAME_INSTR_REGISTRY;
         case FIELD_CREDIT_RATING:
            return FIELD_NAME_CREDIT_RATING;

         case FIELD_ACCRUED_PREMIUM_AMT:
            return FIELD_NAME_ACCRUED_PREMIUM_AMT;
         case FIELD_EVENT_PAYMENT_AMT:
            return FIELD_NAME_EVENT_PAYMENT_AMT;
         case FIELD_ALIGNMENT_INTEREST_RATE:
            return FIELD_NAME_ALIGNMENT_INTEREST_RATE;
         case FIELD_SETTLEMENT_TYPE:
            return FIELD_NAME_SETTLEMENT_TYPE;
         case FIELD_IS_BLOCK_ONLY:
            return FIELD_NAME_IS_BLOCK_ONLY;
         case FIELD_FLEX_ALLOWED:
            return FIELD_NAME_FLEX_ALLOWED;
         case FIELD_HEDGE_MARKET_ID:
            return FIELD_NAME_HEDGE_MARKET_ID;
         default:
            return "Unknown";
      }
   }
}
