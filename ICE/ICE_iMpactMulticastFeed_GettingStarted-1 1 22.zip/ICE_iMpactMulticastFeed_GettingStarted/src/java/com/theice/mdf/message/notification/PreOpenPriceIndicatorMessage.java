package com.theice.mdf.message.notification;

import com.theice.mdf.message.FieldInfo;
import com.theice.mdf.message.MDSequencedMessageWithMarketID;
import com.theice.mdf.message.RawMessageFactory;

import java.nio.ByteBuffer;

/**
 * PreOpenPriceIndicatorMessage.java
 * @author David Chen
 */

public class PreOpenPriceIndicatorMessage extends MDSequencedMessageWithMarketID
{
	private static final short MESSAGE_LENGTH = 28;

	public long PreOpenPrice;
   
	public long DateTime;
	public char HasPreOpenVolume;
	public int PreOpenVolume;

   public PreOpenPriceIndicatorMessage()
   {
      MessageType = RawMessageFactory.PreOpenPriceIndicatorMessageType;
      MessageBodyLength = MESSAGE_LENGTH - HEADER_LENGTH;
   }

	public synchronized byte[] serialize()
	{
		// Buffer is pre-serialized, so that serialization occurs only once.
		if( SerializedContent == null )
		{
			SerializedContent = ByteBuffer.allocate( MESSAGE_LENGTH );

         serializeHeader();
			SerializedContent.putLong(PreOpenPrice);
			SerializedContent.putLong(DateTime);
			SerializedContent.put((byte) HasPreOpenVolume);
			SerializedContent.putInt(PreOpenVolume);

			SerializedContent.rewind();
         if (SHORT_LOG_STR_PRE_ALLOCATED)
         {
            getShortLogStr();
         }
		}

		return SerializedContent.array();
	}

   public String getShortLogStr()
   {
      if (ShortLogStr==null)
      {
			//noinspection StringBufferReplaceableByString
			StringBuilder strBuf = new StringBuilder();
         strBuf.append( getLogHeaderShortStr());

			strBuf.append( PreOpenPrice );
         strBuf.append( LOG_FLD_DELIMITER );
			strBuf.append( DateTime );
         strBuf.append( LOG_FLD_DELIMITER );
			strBuf.append( HasPreOpenVolume );
			strBuf.append( LOG_FLD_DELIMITER );
			strBuf.append( PreOpenVolume );
			strBuf.append( LOG_FLD_DELIMITER );

			ShortLogStr = strBuf.toString();
      }

      return ShortLogStr;
   }

	protected void deserializeContent( ByteBuffer inboundcontent )
	{
		PreOpenPrice = inboundcontent.getLong();
		DateTime = inboundcontent.getLong();
		if ( inboundcontent.hasRemaining()){
			HasPreOpenVolume = (char) inboundcontent.get();
			PreOpenVolume = inboundcontent.getInt();
		}
	}

	public String toString()
	{
		//noinspection StringBufferReplaceableByString
		StringBuilder str = new StringBuilder();
      str.append(super.toString());
		str.append("PreOpenPrice=");
		str.append(PreOpenPrice);
		str.append( "|");
		str.append("DateTime=");
		str.append(DateTime);
		str.append( "|");
		str.append("HasPreOpenVolume=");
		str.append(HasPreOpenVolume);
		str.append( "|");
		str.append("PreOpenVolume=");
		str.append(PreOpenVolume);
		str.append( "|");
		return str.toString();
	}

}

