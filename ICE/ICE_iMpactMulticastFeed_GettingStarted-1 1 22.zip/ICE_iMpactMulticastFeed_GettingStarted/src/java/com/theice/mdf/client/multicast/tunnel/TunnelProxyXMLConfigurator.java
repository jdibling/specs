package com.theice.mdf.client.multicast.tunnel;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.theice.mdf.client.exception.InitializationException;

/**
 * THE CLASSES USED HERE, INCLUDING THE MESSSAGE CLASSES ARE EXAMPLE CODES ONLY.
 * THEY WON'T BE SUPPORTED AS LIBRARY.
 * 
 * @author Barry Fleming
 */
public class TunnelProxyXMLConfigurator extends TunnelProxyConfigurator {
    public static final String CONFIG_KEY_ADDRESSES_FILE = "addresses";
    public static final String DEFAULT_ADDRESSES_FILE = "conf/addresses.xml";
    public static final long DEFAULT_MAGIC_NUMBER = 55555;
    public static final int DEFAULT_AUTO_RECONNECT_INTERVAL = 30;

    private static final String XML_ELEMENT_TUNNEL = "tunnel";
    private static final String XML_ELEMENT_SILO = "silo";
    private static final String XML_ELEMENT_GROUP = "group";

    private static final String XML_ATTRIBUTE_ENVIRONMENT = "environment";
    private static final String XML_ATTRIBUTE_NAME = "name";
    private static final String XML_ATTRIBUTE_IPADDRESS = "ipaddress";
    private static final String XML_ATTRIBUTE_SHORT_NAME = "shortName";
    private static final String XML_ATTRIBUTE_PORT = "port";

    public static void useXmlConfig() throws InitializationException {
        TunnelProxyConfigurator.setInstance(new TunnelProxyXMLConfigurator());
    }

    private Map<String, Group> groups;
    private String environment;
    private String serverAddress;
    private int serverPort;

    private TunnelProxyXMLConfigurator() throws InitializationException {
        String addressesFiles = getAddressFile();
        try {
            Document document = getAddressesDocument(addressesFiles);
            groups = loadAddresses(document);
        } catch (InitializationException e) {
            System.out.println("Failed to load : " + addressesFiles);
            e.printStackTrace();
            throw e;
        }
    }

    protected Document getAddressesDocument(String addressesFileName) throws InitializationException {
        File file = new File(addressesFileName);
        Document document = null;
        if (file.exists()) {
            document = load(file.getAbsolutePath());
        } else {
            throw new InitializationException("The configuration file " + addressesFileName + " cannot be located. Please specify the configuration file with -Dconfig or by naming it "
                    + DEFAULT_ADDRESSES_FILE);
        }
        return document;
    }

    private String getAddressFile() {
        String configFileName = System.getProperty(CONFIG_KEY_ADDRESSES_FILE);
        if (null == configFileName) {
            configFileName = DEFAULT_ADDRESSES_FILE;
        }
        return configFileName;
    }

    @Override
    public String getServerAddress() {
        return serverAddress;
    }

    @Override
    public int getServerPort() {
        return serverPort;
    }

    public String getFormattedGroups() {
        StringBuilder sb = new StringBuilder("Environment: ").append(environment).append("\n");
        int longestShortName = 0;
        int longestName = 0;
        List<Group> groups = getHeaderedGroups();
        for (Group group: groups) {
            int length = group.shortName.length();
            if (length > longestShortName) {
                longestShortName = length;
            }

            length = group.name.length();
            if (length > longestName) {
                longestName = length;
            }
        }

        String format = "    %-" + (longestShortName + 2) + "s %-" + (longestName + 2) + "s %s\n";
        for (Group group: groups) {
            sb.append(String.format(format, group.shortName, group.name, group.getSiloName()));
        }
        return sb.toString();
    }

    private List<Group> getHeaderedGroups() {
        List<Group> groups = new ArrayList<Group>(this.groups.size() + 2);
        groups.add(new GroupHeader("Group Code Name", "Group Full Name", "Silo"));
        groups.add(new GroupHeader("---------------", "---------------", "----"));
        groups.addAll(this.groups.values());
        return groups;
    }

    private Map<String, Group> loadAddresses(Document document) throws InitializationException {
        NodeList rootList = document.getElementsByTagName(XML_ELEMENT_TUNNEL);
        return loadTunnel(rootList.item(0));
    }

    private Map<String, Group> loadTunnel(Node tunnel) {
        NamedNodeMap attributes = tunnel.getAttributes();
        environment = getAttribute(attributes, XML_ATTRIBUTE_ENVIRONMENT);
        Map<String, Group> groups = new LinkedHashMap<String, Group>();
        NodeList siloList = ((Element) tunnel).getElementsByTagName(XML_ELEMENT_SILO);
        for (int i = 0; i < siloList.getLength(); i++) {
            loadSilo(siloList.item(i), groups);
        }
        validateGroups(groups);
        return groups;
    }

    private void loadSilo(Node siloNode, Map<String, Group> groups) {
        Silo silo = buildSilo(siloNode);
        NodeList groupList = ((Element) siloNode).getElementsByTagName(XML_ELEMENT_GROUP);
        for (int i = 0; i < groupList.getLength(); i++) {
            Group group = loadGroup(groupList.item(i), silo);
            if (null != groups.put(group.shortName.toLowerCase(), group)) {
                throw new IllegalStateException("Found a duplicate short name for address groups. Short name was " + group.shortName);
            }
        }
    }

    private Silo buildSilo(Node siloNode) {
        NamedNodeMap attributes = siloNode.getAttributes();
        String name = getAttribute(attributes, XML_ATTRIBUTE_NAME);
        String ipAddress = getAttribute(attributes, XML_ATTRIBUTE_IPADDRESS);
        return new Silo(name, ipAddress);
    }

    private Group loadGroup(Node groupNode, Silo silo) {
        NamedNodeMap attributes = groupNode.getAttributes();
        String name = getAttribute(attributes, XML_ATTRIBUTE_NAME);
        String shortName = getAttribute(attributes, XML_ATTRIBUTE_SHORT_NAME);
        String port = getAttribute(attributes, XML_ATTRIBUTE_PORT);
        return new Group(silo, name, shortName, Integer.parseInt(port));
    }

    private String getAttribute(NamedNodeMap attributes, String key) {
        String value = null;
        Node node = attributes.getNamedItem(key);
        if (null != node) {
            value = node.getNodeValue();
            if (null != value) {
                value = value.trim();
            }
        }
        return value;
    }

    private void validateGroups(Map<String, Group> groups) {
        Set<String> names = new HashSet<String>();
        Set<Integer> ports = new HashSet<Integer>();
        for (Group group: groups.values()) {
            if (false == names.add(group.name)) {
                throw new IllegalStateException("Found a duplicate name for address groups. Name was " + group.name);
            }
            if (false == ports.add(group.port)) {
                throw new IllegalStateException("Found a duplicate ports for address groups. Port was " + group.port);
            }
        }
    }

    protected Document load(String fileName) throws InitializationException {
        Document document = null;
        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            factory.setValidating(false);
            factory.setIgnoringComments(true);
            factory.setIgnoringElementContentWhitespace(true);

            DocumentBuilder builder = factory.newDocumentBuilder();
            document = builder.parse(new File(fileName));
        } catch (ParserConfigurationException e) {
            e.printStackTrace();
            throw new InitializationException(e.getMessage());
        } catch (IOException e) {
            e.printStackTrace();
            throw new InitializationException(e.getMessage());
        } catch (SAXException e) {
            e.printStackTrace();
            throw new InitializationException(e.getMessage());
        }

        return document;
    }

    /**
     * Sets the server address and port of the group associated with
     * groupShortName, if one exists
     * 
     * @param groupShortName
     * @return true if the group is found, false otherwise
     */
    public boolean configureGroup(String groupShortName) {
        if (null != groupShortName) {
            groupShortName = groupShortName.toLowerCase();
        }
        Group group = groups.get(groupShortName);
        if (null != group) {
            serverAddress = group.getIPAddress();
            serverPort = group.port;
            return true;
        }
        return false;
    }

    public static class Silo {
        final String name;
        final String ipAddress;

        public Silo(String name, String ipAddress) {
            this.name = name;
            this.ipAddress = ipAddress;
        }

        @Override
        public boolean equals(Object o) {
            if (o instanceof Silo) {
                Silo other = (Silo) o;
                return name.equals(other.name) && ipAddress.equals(other.ipAddress);
            }
            return false;
        }

        @Override
        public int hashCode() {
            return new StringBuilder(name).append(ipAddress).hashCode();
        }
    }

    public static class Group {
        final Silo silo;
        final String name;
        final String shortName;
        final int port;

        public Group(Silo silo, String name, String shortName, int port) {
            this.silo = silo;
            this.name = name;
            this.shortName = shortName;
            this.port = port;
        }

        public String getSiloName() {
            return silo.name;
        }

        public String getIPAddress() {
            return silo.ipAddress;
        }

        @Override
        public String toString() {
            StringBuilder sb = new StringBuilder("Group[");
            sb.append("name=").append(name);
            sb.append(", shortName=").append(shortName);
            sb.append(", silo=").append(silo.name);
            sb.append(", ipAddress=").append(silo.ipAddress);
            sb.append(", port=").append(port).append("]");
            return sb.toString();
        }

        @Override
        public boolean equals(Object o) {
            if (o instanceof Group) {
                Group other = (Group) o;
                return name.equals(other.name) && shortName.equals(other.shortName) && port == other.port && silo.equals(other.silo);
            }
            return false;
        }

        @Override
        public int hashCode() {
            return toString().hashCode();
        }
    }

    static class GroupHeader extends Group {
        final String siloName;
        public GroupHeader(String shortName, String name, String silo) {
            super(null, name, shortName, -1);
            siloName = silo;
        }

        @Override
        public String getSiloName() {
            return siloName;
        }
    }
}
