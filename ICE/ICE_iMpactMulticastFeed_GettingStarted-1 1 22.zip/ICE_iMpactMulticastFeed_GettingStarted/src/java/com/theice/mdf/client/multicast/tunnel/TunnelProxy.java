package com.theice.mdf.client.multicast.tunnel;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.Socket;
import org.apache.log4j.Logger;

import com.theice.mdf.client.domain.EndPointInfo;
import com.theice.mdf.client.exception.InitializationException;
import com.theice.mdf.message.request.TunnelingProxyRequest;

/**
 * THE CLASSES USED HERE, INCLUDING THE MESSSAGE CLASSES ARE EXAMPLE CODES ONLY.
 * THEY WON'T BE SUPPORTED AS LIBRARY.
 * 
 * TunnelProxy
 * 
 * @author Adam Athimuthu  
 */
public class TunnelProxy 
{
   private static final Logger logger = Logger.getLogger(TunnelProxy.class.getName());
   private EndPointInfo socketEndPoint = null;
   private Socket socket = null;

   public TunnelProxy()
   {
      String ipAddress = getConfigurator().getServerAddress();
      int port = getConfigurator().getServerPort();
      socketEndPoint = new EndPointInfo(ipAddress, port);
   }
	
	/**
	 * Open tunnel
	 * @throws Exception
	 */
   public void openTunnel() throws Exception
   {
      try
      {
         logger.info("Opening Tunnel on : "+socketEndPoint.toString());
			
         socket=new Socket(socketEndPoint.getIpAddress(),socketEndPoint.getPort());
         socket.setTcpNoDelay(true);
      }
      catch(Exception e)
      {
         e.printStackTrace();
         throw(e);
      }
   }

	/**
	 * close tunnel
	 */
   public void closeTunnel()
   {
      if(socket!=null)
      {
         logger.info("Closing Tunnel : "+socketEndPoint.toString());
         try
         {
            socket.close();
         }
         catch(Exception e)
         {
         }
      }
   }
	
	/**
	 * send tunnel request
	 * @throws Exception
	 */
   public void sendTunnelRequest() throws Exception
   {
      TunnelingProxyRequest tunnelingRequest=new TunnelingProxyRequest();
		
		tunnelingRequest.RequestSeqID=12345;
        tunnelingRequest.TunnelingMagicNumber = getConfigurator().getTunnelingMagicNumber();
        tunnelingRequest.IsCompressed = getConfigurator().isEnableDataCompression() ? 'Y' : 'N';
        tunnelingRequest.IsLowLatency = getConfigurator().isEnableCompressLowLatency() ? 'Y' : 'N';
		
		if(logger.isDebugEnabled())
		{
			logger.debug("Sending : "+tunnelingRequest.toString());
		}
		
		OutputStream outStream=socket.getOutputStream();
		
		outStream.write(tunnelingRequest.serialize());
		
		return;
	}
	
   public EndPointInfo getSocketEndPoint()
   {
      return(socketEndPoint);
   }
	
   public DataInputStream getInputStream() throws IOException
   {
      DataInputStream stream=null;
		
      if(socket!=null)
      {
         stream=new DataInputStream(socket.getInputStream());
      }
		
      return(stream);
   }

   private static Thread startThread(Runnable task, String taskName) {
      Thread thread = new Thread(task, taskName);
      thread.start();
      return thread;
   }

   protected static void runTunnelProxy(TunnelProxy tunnelProxy)
   {
      logger.info("TunnelProxy autoReconnect is set to " + getConfigurator().isTunnelProxyAutoReconnect());
      Thread healthMonitorThread = null;
      boolean isAutoReconnect = getConfigurator().isTunnelProxyAutoReconnect();
      int autoReconnectInterval = getConfigurator().getTunnelProxyAutoReconnectInterval();
      do
      {
         try
         {
            TunnelProxyManager.getInstance().initialize();
            logger.info("TunnelProxy opening tunnel...");

            tunnelProxy.openTunnel();
            Thread tunnelReceiverThread = startThread(new TunnelReceiver(tunnelProxy.getSocketEndPoint(), new DataInputStream(tunnelProxy.getInputStream())), "TunnelReceiver");
            tunnelProxy.sendTunnelRequest();
            if (isAutoReconnect)
            {
               healthMonitorThread = startThread(new ConnectionHealthMonitor(3000, 30000, tunnelProxy.getInputStream()), "HealthMonitor");
            }

            logger.info("Joining Tunnel Receiver Thread...");
            tunnelReceiverThread.join();
         }
         catch(IOException e)
         {
            logger.error("IOException:"+e,e);
         }
         catch(InitializationException e)
         {
            logger.error("InitializationException:"+e,e);
         }
         catch(Exception e)
         {
            logger.error("Exception:"+e,e);
         }
         finally
         {
            tunnelProxy.closeTunnel();
            if (healthMonitorThread!=null)
            {
               healthMonitorThread.interrupt();
            }
         }
			
         if (isAutoReconnect)
         {
            logger.info("TunnelProxy autoReconnect is true... will reconnect in about "+autoReconnectInterval+" seconds.");
            try
            {
               Thread.sleep(autoReconnectInterval*1000);
            }
            catch(Exception ex)
            {
               logger.error("Tunnel Proxy exception when waiting to reconnect:"+ex);
            }
         }
      } 
      while (isAutoReconnect);
   }

   public static TunnelProxyConfigurator getConfigurator()
   {
      return TunnelProxyConfigurator.getInstance();
   }

   public static void main(String[] args)
   {
      TunnelProxy tunnelProxy = new TunnelProxy();
      logger.info("TunnelProxy Starting...");

      runTunnelProxy(tunnelProxy);
   }
}
