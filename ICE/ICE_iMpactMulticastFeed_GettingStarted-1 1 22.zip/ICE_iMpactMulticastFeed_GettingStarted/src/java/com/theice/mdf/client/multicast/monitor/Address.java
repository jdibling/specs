package com.theice.mdf.client.multicast.monitor;

/**
 * <code>Address</code>
 *
 * @author Barry Fleming
 */
public class Address {
    private final int minAddress;
    private final int maxAddress;
    private final String environment;

    public Address(String address, String environment) {
        if (isCidr(address)) {
            String[] values = address.split("/");
            int addressNum = getAddress(values[0]);
            int mask = getMask(values[1]);
            minAddress = addressNum & mask;
            maxAddress = minAddress | ~mask;
        } else {
            minAddress = getAddress(address);
            maxAddress = minAddress;
        }
        this.environment = environment;
    }

    private boolean isCidr(String address) {
        return address.contains("/");
    }

    private int getAddress(String addressStr) {
        int address = 0;
        String[] octets = addressStr.split("\\.");
        for (int i = 0; i < 4; i++) {
            int octet = (Integer.parseInt(octets[i]) & 0xff);
            octet = octet << (8 * (3 - i));
            address |= octet;
        }
        return address;
    }

    private int getMask(String maskStr) {
        int mask = 0;
        int maskRep = Integer.parseInt(maskStr);
        for (int i = 0; i < maskRep; i++) {
            mask |= (1 << 31 - i);
        }
        return mask;
    }

    private String cleanAddress(String address) {
        return address.replaceAll("\\[", "").replaceAll("\\]", "");
    }

    public boolean matches(String addressStr) {
        int address = getAddress(cleanAddress(addressStr));
        return address == minAddress || (address >= minAddress && address <= maxAddress);
    }

    private String getAddressAsString(int value) {
        StringBuilder address = new StringBuilder();
        for (int i = 3; i > -1; i--) {
            int octet = (value >> (8 * i)) & 0xff;
            address.append(octet);
            if (i > 0)
                address.append(".");
        }
        return address.toString();
    }

    public String toString() {
        String address;
        if (minAddress == maxAddress) {
            address = getAddressAsString(minAddress);
        } else {
            address = getAddressAsString(minAddress) + "-" + getAddressAsString(maxAddress);
        }
        return "[" + address + "]";
    }

    public String getEnvironment() {
        return environment;
    }
}
