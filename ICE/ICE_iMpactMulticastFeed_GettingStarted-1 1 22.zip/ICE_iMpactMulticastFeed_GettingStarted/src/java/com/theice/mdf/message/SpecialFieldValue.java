package com.theice.mdf.message;

import java.nio.ByteBuffer;

/**
 * User: dkim
 * Date: 10/22/14
 * Time: 9:32 AM
 */
public class SpecialFieldValue {

   public static final byte ALT_PRICE = 1;
   public static final byte ALT_HIGH_PRICE = 2;
   public static final byte ALT_LOW_PRICE = 3;
   public static final byte ALT_VWAP = 4;
   public static final byte ALT_LAST_TRADE_PRICE = 5;
   public static final byte FIELD_UNKNOWN = Byte.MAX_VALUE;

   public static final short FIELD_UNKNOWN_LENGTH = 190;
   public static final char[] FIELD_UNKNOWN_VALUE = MessageUtil.toRawChars(
           "This is an unknown test field that is only sent out in test env. Per iMpact spec, "+
                   "client is required to handle it, by reading the right number of bytes based on the field length value.", FIELD_UNKNOWN_LENGTH);

   public static final String FIELD_NAME_ALT_PRICE = "AltPrice";
   public static final String FIELD_NAME_ALT_LAST_TRADE_PRICE = "AltLastTradePrice";
   public static final String FIELD_NAME_ALT_VWAP = "AltVWAP";
   public static final String FIELD_NAME_ALT_LOW_PRICE = "AltLowPrice";
   public static final String FIELD_NAME_ALT_HIGH_PRICE = "AltHighPrice";

   private byte fieldId;
   private Object value;

   public byte getFieldId() {
      return fieldId;
   }

   public Object getValue() {
      return value;
   }

   public SpecialFieldValue(byte fieldId, Object value) {
      this.fieldId = fieldId;
      this.value = value;
   }

   public SpecialFieldValue(ByteBuffer inbound) {
      fieldId = inbound.get();
      short length = inbound.getShort();
      switch (fieldId) {
         case ALT_PRICE:
         case ALT_HIGH_PRICE:
         case ALT_LOW_PRICE:
         case ALT_VWAP:
         case ALT_LAST_TRADE_PRICE:
            value = inbound.getLong();
            break;
         case FIELD_UNKNOWN:
            char[] charArray = new char[length];
            for( int i=0; i<charArray.length; i++ )
            {
               charArray[i] = (char)inbound.get();
            }
            value = charArray;
            break;
         default:
            value = new byte[length];
            inbound.get((byte[]) value);
            break;
      }
   }

   public short getLength() {

      switch (fieldId) {
         case ALT_PRICE:
         case ALT_HIGH_PRICE:
         case ALT_LOW_PRICE:
         case ALT_VWAP:
         case ALT_LAST_TRADE_PRICE:
            return 8;
         case FIELD_UNKNOWN:
            return FIELD_UNKNOWN_LENGTH;
         default:
            throw new UnsupportedOperationException("Error");
      }
   }


   public void putValue(ByteBuffer serializedContent) {
      switch (fieldId) {
         case ALT_PRICE:
         case ALT_HIGH_PRICE:
         case ALT_LOW_PRICE:
         case ALT_VWAP:
         case ALT_LAST_TRADE_PRICE:
            if ( value != null)
               serializedContent.putLong((Long) value);
            else
               serializedContent.putLong(0L);
            return;
         case FIELD_UNKNOWN:
            char[] charArray = (char[])value;
            for( int i=0; i<charArray.length; i++ )
               serializedContent.put((byte)charArray[i]);
            return;
         default:
            throw new UnsupportedOperationException("Error");
      }
   }

   public String getFieldName() {

      switch (fieldId) {
         case ALT_PRICE:
            return FIELD_NAME_ALT_PRICE;
         case ALT_HIGH_PRICE:
            return FIELD_NAME_ALT_HIGH_PRICE;
         case ALT_LOW_PRICE:
            return FIELD_NAME_ALT_LOW_PRICE;
         case ALT_VWAP:
            return FIELD_NAME_ALT_VWAP;
         case ALT_LAST_TRADE_PRICE:
            return FIELD_NAME_ALT_LAST_TRADE_PRICE;
         default:
            return "Unknown";
      }
   }
}
