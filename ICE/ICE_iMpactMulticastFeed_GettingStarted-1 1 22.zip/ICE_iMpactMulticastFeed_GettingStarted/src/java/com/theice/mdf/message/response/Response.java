package com.theice.mdf.message.response;

import com.theice.mdf.message.MDMessage;

/**
 * User: dchen
 * Date: Jan 11, 2007
 * Time: 4:53:35 PM
 */
public abstract class Response extends MDMessage
{
	public int RequestSeqID;

   public String toString()
   {
      //noinspection StringBufferReplaceableByString
      StringBuilder str = new StringBuilder();

      str.append(super.toString());
      str.append("RequestSeqID=");
		str.append(RequestSeqID);
		str.append( "|");

      return str.toString();
   }
}
