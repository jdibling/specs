package com.theice.mdf.client.domain;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.theice.mdf.message.MDSequencedMessageWithMarketIDSpecialFields;
import com.theice.mdf.message.SpecialFieldValue;
import com.theice.mdf.message.notification.MarketSnapshotMessage;
import com.theice.mdf.message.notification.SpecialFieldMessage;

/**
 * THE CLASSES USED HERE, INCLUDING THE MESSAGE CLASSES ARE EXAMPLE CODES ONLY.
 * THEY WON'T BE SUPPORTED AS LIBRARY.
 *
 * TODO Use trading status to update the underlying market's state
 *
 * @author Adam Athimuthu
 * Date: Aug 7, 2007
 * Time: 3:33:02 PM
 */
public class MarketStatistics
{
   private short _marketType;
   private int _marketID;
   private char _tradingStatus;
   private int _totalVolume;
   private int _blockVolume;
   private int _efsVolume;
   private int _efpVolume;
   private int _openInterest;
   private String _openInterestDate="";
   private long _openingPrice;
   private long _settlementPrice;
   private long _settleDateTime;
   private char _settlementOfficial;
   private long _high;
   private long _low;
   private long _vwap;
   private int _numOfBookEntries;
   private long _lastTradePrice;
   private int _lastTradeQuantity;
   private long _lastTradeDateTime;
   private Map<String, SpecialField> specialFieldValues = new LinkedHashMap<String, SpecialField>();

   public MarketStatistics()
   {
   }

   public MarketStatistics(MarketSnapshotMessage snapshot)
   {
      _marketType=snapshot.MarketType;
      _marketID=snapshot.getMarketID();
      _tradingStatus=snapshot.TradingStatus;
      _totalVolume=snapshot.TotalVolume;
      _blockVolume=snapshot.BlockVolume;
      _efsVolume=snapshot.EFSVolume;
      _efpVolume=snapshot.EFPVolume;
      _openInterest=snapshot.OpenInterest;
      char[] oiDate = snapshot.OpenInterestDate;
      if (oiDate!=null && oiDate.length>0 && oiDate[0]!='\0')
      {
         _openInterestDate=new String(oiDate);
      }
      _openingPrice=snapshot.OpeningPrice;
      _settlementPrice=snapshot.SettlementPrice;
      _settleDateTime=snapshot.SettlementPriceDateTime;
      _settlementOfficial=snapshot.IsSettlementPriceOfficial;
      _high=snapshot.High;
      _low=snapshot.Low;
      _vwap=snapshot.VWAP;
      _numOfBookEntries=snapshot.NumOfBookEntries;
      _lastTradePrice=snapshot.LastTradePrice;
      _lastTradeQuantity=snapshot.LastTradeQuantity;
      _lastTradeDateTime=snapshot.LastTradeDateTime;
      setSpecialFieldValues(snapshot);
   }

   public short getMarketType()
   {
      return _marketType;
   }

   public int getMarketID()
   {
      return _marketID;
   }

   public char getTradingStatus()
   {
      return _tradingStatus;
   }

   public int getTotalVolume()
   {
      return _totalVolume;
   }

   public int getBlockVolume()
   {
      return _blockVolume;
   }

   public int getEfsVolume()
   {
      return _efsVolume;
   }

   public int getEfpVolume()
   {
      return _efpVolume;
   }

   public int getOpenInterest()
   {
      return _openInterest;
   }

   public String getOpenInterestDate()
   {
      return _openInterestDate;
   }

   public long getOpeningPrice()
   {
      return _openingPrice;
   }

   public long getSettlementPrice()
   {
      return _settlementPrice;
   }

   public long getSettleDateTime()
   {
      return _settleDateTime;
   }

   public char getSettlementOfficial()
   {
      return _settlementOfficial;
   }

   public long getHigh()
   {
      return _high;
   }

   public long getLow()
   {
      return _low;
   }

   public long getVwap()
   {
      return _vwap;
   }

   public int getNumOfBookEntries()
   {
      return _numOfBookEntries;
   }

   public long getLastTradePrice()
   {
      return _lastTradePrice;
   }

   public int getLastTradeQuantity()
   {
      return _lastTradeQuantity;
   }

   public long getLastTradeDateTime()
   {
      return _lastTradeDateTime;
   }

   public boolean hasSpecialFieldValues() {
      return false == specialFieldValues.isEmpty();
   }

   public List<SpecialField> getSpecialFieldValues() {
      return new ArrayList<SpecialField>(specialFieldValues.values());
   }

   public void setMarketType(short type)
   {
      _marketType = type;
   }

   public void setMarketID(int _marketid)
   {
      _marketID = _marketid;
   }

   public void setTradingStatus(char status)
   {
      _tradingStatus = status;
   }

   public void setTotalVolume(int volume)
   {
      _totalVolume = volume;
   }

   public void setBlockVolume(int volume)
   {
      _blockVolume = volume;
   }

   public void setEfsVolume(int volume)
   {
      _efsVolume = volume;
   }

   public void setEfpVolume(int volume)
   {
      _efpVolume = volume;
   }

   public void setOpenInterest(int interest)
   {
      _openInterest = interest;
   }

   public void setOpenInterestDate(String date)
   {
      _openInterestDate = date;
   }

   public void setOpeningPrice(long price)
   {
      _openingPrice = price;
   }

   public void setSettlementPrice(long price)
   {
      _settlementPrice = price;
   }

   public void setSettlePriceDateTime(long dateTime)
   {
      _settleDateTime = dateTime;
   }

   public void setSettlementOfficial(char isOfficial)
   {
      _settlementOfficial = isOfficial;
   }

   public void setHigh(long _high)
   {
      this._high = _high;
   }

   public void setLow(long _low)
   {
      this._low = _low;
   }

   public void setVwap(long _vwap)
   {
      this._vwap = _vwap;
   }

   public void setNumOfBookEntries(int numOfBookEntries)
   {
      _numOfBookEntries = numOfBookEntries;
   }

   public void setLastTradePrice(long tradePrice)
   {
      _lastTradePrice = tradePrice;
   }

   public void setLastTradeQuantity(int tradeQuantity)
   {
      _lastTradeQuantity = tradeQuantity;
   }

   public void setLastTradeDateTime(long tradeDateTime)
   {
      _lastTradeDateTime = tradeDateTime;
   }

   public void setSpecialFieldValues(MDSequencedMessageWithMarketIDSpecialFields message) {
      if(null != message) {
         SpecialFieldMessage specialFieldMessage = message.getSpecialFieldMessage();
         if(null != specialFieldMessage) {
            for(SpecialFieldValue sfv: specialFieldMessage.getFields()) {
               SpecialField specialField = new SpecialField(sfv, message);
               specialFieldValues.put(specialField.getKey(), specialField);
            }
         }
      }
   }

   /**
    * to String
    * @return
    */
   public String toString()
   {
      StringBuilder buf=new StringBuilder("Market Statistics");
      buf.append("[MarketType=").append(_marketType).append("]");
      buf.append("[MarketId=").append(_marketID).append("]");
      buf.append("[TradingStatus=").append(_tradingStatus).append("]");
      buf.append("[TotalVol=").append(_totalVolume).append("]");
      buf.append("[BlockVol=").append(_blockVolume).append("]");
      buf.append("[EFS=").append(_efsVolume).append("]");
      buf.append("[EFP=").append(_efpVolume).append("]");
      buf.append("[OpenInterest=").append(_openInterest).append("]");
      buf.append("[OpenInterestDate=").append(_openInterestDate).append("]");
      buf.append("[OpeningPrice=").append(_openingPrice).append("]");
      buf.append("[SettlementPrice=").append(_settlementPrice).append("]");
      buf.append("[High=").append(_high).append("]");
      buf.append("[Low=").append(_low).append("]");
      buf.append("[VWAP=").append(_vwap).append("]");
      buf.append("[NumBookEntries=").append(_numOfBookEntries).append("]");
      buf.append("[LastTradePrice=").append(_lastTradePrice).append("]");
      buf.append("[LastTradeQty=").append(_lastTradeQuantity).append("]");
      buf.append("[LastTradeDateTime=").append(_lastTradeDateTime).append("]");
      return(buf.toString());
   }
}
