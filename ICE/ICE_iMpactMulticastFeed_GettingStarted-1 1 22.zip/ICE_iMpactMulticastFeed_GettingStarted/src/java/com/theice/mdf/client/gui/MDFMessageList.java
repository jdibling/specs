package com.theice.mdf.client.gui;

import javax.swing.*;

/**
 * THE CLASSES USED HERE, INCLUDING THE MESSSAGE CLASSES ARE EXAMPLE CODES ONLY.
 * THEY WON'T BE SUPPORTED AS LIBRARY.
 * 
 * @author Adam Athimuthu
 * Date: Aug 1, 2007
 * Time: 5:20:17 PM
 *
 */
public class MDFMessageList extends JList
{
    public MDFMessageList()
    {
        super();
    }

    public MDFMessageList(ListModel model)
    {
        super(model);
    }

}
