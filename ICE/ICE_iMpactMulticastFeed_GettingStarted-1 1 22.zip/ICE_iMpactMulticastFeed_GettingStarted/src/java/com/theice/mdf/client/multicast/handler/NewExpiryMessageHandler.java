package com.theice.mdf.client.multicast.handler;

import org.apache.log4j.Logger;

import com.theice.mdf.client.domain.Market;
import com.theice.mdf.client.domain.MarketInterface;
import com.theice.mdf.client.domain.MarketsHolder;
import com.theice.mdf.client.domain.book.Book;
import com.theice.mdf.client.domain.book.FullOrderBook;
import com.theice.mdf.client.domain.book.NullBook;
import com.theice.mdf.client.domain.book.PriceLevelBook;
import com.theice.mdf.client.message.PriceFeedMessage;
import com.theice.mdf.client.process.AppManager;
import com.theice.mdf.client.process.handlers.AbstractMarketMessageHandler;
import com.theice.mdf.message.notification.NewExpiryMessage;

public class NewExpiryMessageHandler extends AbstractMarketMessageHandler {
    private static NewExpiryMessageHandler _instance = new NewExpiryMessageHandler();

    private static final Logger logger = Logger.getLogger(NewExpiryMessageHandler.class.getName());

    public static NewExpiryMessageHandler getInstance() {
        return _instance;
    }

    private NewExpiryMessageHandler() {
    }

    /**
     * handle the message
     * 
     * @param message
     */
    @Override
    protected void handleMessage(PriceFeedMessage priceFeedMessage) {
        //special case
        //New Expiry markets are handled in PriceLevelMulticastDispatcher (message consuming thread),
        //which then calls the processNewExpiryMessage(NewExpiryMessage) method in this class.
    }

    public Market processNewExpiryMessage(NewExpiryMessage message) {
        MarketInterface market = MarketsHolder.getInstance().findMarket(message.getMarketID());
        if (market != null) {
            logger.error("New Expiry market already exists. marketID=" + message.getMarketID());
            return null;
        }
        Book book = getBook();
        return createNewMarket(message, book);
    }

    private Book getBook() {
        switch (AppManager.getMulticastChannelContext()) {
            case PRICELEVEL:
                return new PriceLevelBook(MarketInterface.NUMBER_OF_PRICELEVELS);
            case FULLORDERDEPTH:
                return new FullOrderBook();
            default:
                return new NullBook();
        }
    }

    private Market createNewMarket(NewExpiryMessage message, Book book) {
        Market newExpiryMarket = null;
        try {
            newExpiryMarket = new Market(message, book);
            MarketsHolder.getInstance().storeMarket(newExpiryMarket);
            updateTheModelsInsideTheContext(newExpiryMarket);
        } catch (Exception ex) {
            logger.error("Exception when initializing New Expiry: marketID=" + message.getMarketID(), ex);
            newExpiryMarket = null;
        }
        return newExpiryMarket;
    }

    private void updateTheModelsInsideTheContext(Market newExpiryMarket) {
        AppManager.getAppContext().cacheMarket(newExpiryMarket);
    }
}
