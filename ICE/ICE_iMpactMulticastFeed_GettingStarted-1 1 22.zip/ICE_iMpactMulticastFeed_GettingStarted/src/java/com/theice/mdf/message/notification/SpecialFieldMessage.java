package com.theice.mdf.message.notification;

import com.theice.mdf.message.*;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;

/**
 * User: dkim
 * Date: 10/20/14
 * Time: 2:58 PM
 */
public class SpecialFieldMessage  extends MDSequencedMessage
{
   private int marketId = -1;

   @SuppressWarnings("unused")
   private void addField( byte fieldId, Object value ) {
      fields.add(new SpecialFieldValue(fieldId, value));
   }

   private List<SpecialFieldValue> fields;

   @Override
   public boolean isSpecialFieldMessage(){
      return true;
   }

   public SpecialFieldMessage()
   {
      MessageType = RawMessageFactory.specialFieldMessageType;
      fields = new ArrayList<SpecialFieldValue>(10);

   }
   public SpecialFieldMessage(MDSequencedMessageWithMarketIDSpecialFields message)
   {
      MessageType = RawMessageFactory.specialFieldMessageType;
      this.fields = new ArrayList<SpecialFieldValue>(message.specialFieldValues);
      marketId = message.getMarketID();
      calculateMessageBodyLength();
   }

   public List<SpecialFieldValue> getFields() {
      return fields;
   }

   private void calculateMessageBodyLength() {
      int fieldLength = 0;
      for (SpecialFieldValue field: fields ) {
         fieldLength = (short) (fieldLength + 1 + 2 + field.getLength());
      }
      MessageBodyLength = (short) (fieldLength + 1);
   }

   public short getMessageBodyLength()
   {
      return MessageBodyLength;
   }

   public short getMessageLength()
   {
      return (short)(MessageBodyLength + HEADER_LENGTH);
   }



   public synchronized byte[] serialize()
   {
      // Buffer is pre-serialized, so that serialization occurs only once.
      if( SerializedContent == null )
      {
         int messageLength =  MessageBodyLength + HEADER_LENGTH;

         SerializedContent = ByteBuffer.allocate(messageLength);

         serializeHeader();
         SerializedContent.put((byte) fields.size());
         for (SpecialFieldValue field: fields ) {
            SerializedContent.put(field.getFieldId());
            SerializedContent.putShort(field.getLength());
            field.putValue(SerializedContent);
         }

         SerializedContent.rewind();

         if (SHORT_LOG_STR_PRE_ALLOCATED)
         {
            getShortLogStr();
         }
      }

      return SerializedContent.array();
   }

   @Override
   public int getMarketID() {
      return marketId;
   }

   @Override
   public void setMarketID(int marketId) {
      this.marketId=marketId;
   }

   public String getShortLogStr()
   {
      if (ShortLogStr==null)
      {
         StringBuilder strBuf = new StringBuilder();
         strBuf.append( getLogHeaderShortStr());

         strBuf.append( fields.size() );
         strBuf.append( LOG_FLD_DELIMITER );

         for (SpecialFieldValue field: fields ) {
            strBuf.append(field.getFieldId());
            strBuf.append( LOG_FLD_DELIMITER );
            strBuf.append(field.getLength());
            strBuf.append( LOG_FLD_DELIMITER );
            strBuf.append( field.getValue() );
            strBuf.append( LOG_FLD_DELIMITER );
         }
         ShortLogStr = strBuf.toString();
      }

      return ShortLogStr;
   }

   protected void deserializeContent( ByteBuffer inboundcontent )
   {
      int numFields = inboundcontent.get();
      for ( int i =0; i < numFields; i++) {
         fields.add(new SpecialFieldValue(inboundcontent));
      }
   }

   public String toString()
   {
      StringBuilder str = new StringBuilder();

      str.append(super.toString());

      for (SpecialFieldValue field: fields ) {
         str.append(field.getFieldName()).append("=");
         str.append(field.getValue());
         str.append("|");
      }
      return str.toString();
   }

}

