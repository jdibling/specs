package com.theice.mdf.client.gui.panel;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.util.Iterator;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.DefaultListSelectionModel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ListSelectionModel;
import javax.swing.ScrollPaneConstants;
import javax.swing.border.TitledBorder;

import com.theice.mdf.client.domain.InvestigationStatus;
import com.theice.mdf.client.domain.MarketInterface;
import com.theice.mdf.client.domain.SpotTradeInfo;
import com.theice.mdf.client.domain.Trade;
import com.theice.mdf.client.process.handlers.TradeMessageHandler;
import com.theice.mdf.client.util.MDFUtil;
import com.theice.mdf.message.SpecialFieldValue;
import com.theice.mdf.message.notification.TradeMessage;

/**
 * THE CLASSES USED HERE, INCLUDING THE MESSAGE CLASSES ARE EXAMPLE CODES ONLY.
 * THEY WON'T BE SUPPORTED AS LIBRARY.
 *
 * Trade History - displays the recent 50 trades for a given market
 *
 * @author Adam Athimuthu
 */
public class TradeHistoryPanel extends JPanel
{
   private MarketInterface _market=null;

   private TradeHistoryListModel _tradesListModel=new TradeHistoryListModel();
   private JList _tradesList=new JList(_tradesListModel);

   public TradeHistoryPanel(MarketInterface market)
   {
      super(new BorderLayout());

      _market=market;

      buildPanel();
      init();
   }

   private void buildPanel()
   {
      setBorder(new TitledBorder(BorderFactory.createLineBorder(Color.blue, 1),"Recent Trades",
              TitledBorder.LEADING,TitledBorder.TOP,new Font("Arial",Font.BOLD,12)));

      _tradesList.setBackground(Color.black);
      _tradesList.setForeground(Color.white);
      _tradesList.setFont(new Font("Arial",Font.PLAIN,12));
      _tradesList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

      DefaultListSelectionModel selectionModel=new DefaultListSelectionModel()
      {
         public boolean isSelectedIndex(int index)
         {
            return (false);
         }

         public boolean isSelectionEmpty()
         {
            return (true);
         }
      };
      _tradesList.setSelectionModel(selectionModel);

      JScrollPane scrollPane=new JScrollPane(_tradesList);
      scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
      add(scrollPane,BorderLayout.CENTER);

      refresh();

   }

   /**
    * refresh information from the market's recent trades list
    */
   public synchronized void refresh()
   {
      String[] trades=new String[0];

      synchronized(_market.getUnderlyingMarket())
      {
         List<Trade> recentTrades=_market.getRecentTrades();

         int size=recentTrades.size();

         if(size>0)
         {
            trades=new String[size];

            int index=0;

            for(Iterator it=recentTrades.iterator();it.hasNext();index++)
            {
               Trade trade=(Trade) it.next();

               trades[size-index-1]=getTradeInformation(trade);
            }
         }
         else
         {
            trades=new String[0];
         }
      }

      _tradesListModel.setHistory(trades);
      this.repaint();
   }

   /**
    * Get trade information as a string so we can display in the history panel
    * @param tradeMessage
    * @return
    */
   private String getTradeInformation(Trade trade)
   {
      StringBuilder buffer=new StringBuilder(" ");

      TradeMessage tradeMessage= trade.getTradeMessage();

      buffer.append(tradeMessage.Quantity);
      buffer.append(" @ ");
      buffer.append(tradeMessage.Price);
      buffer.append("   ");
      buffer.append("(").append(MDFUtil.tradeMsTimeFormatter.format(tradeMessage.DateTime)).append(") ");

      if(trade.isSpotTrade())
      {
         SpotTradeInfo _spotTradeInfo = trade.getSpotTradeInfo();
         buffer.append("   ");
         buffer.append("DeliveryBeginDateTime:");
         buffer.append(MDFUtil.tradeMsTimeFormatter.format(_spotTradeInfo.getDeliveryBeginDateTime()));
         buffer.append("   ");
         buffer.append("DeliveryEndDateTime:");
         buffer.append(MDFUtil.tradeMsTimeFormatter.format(_spotTradeInfo.getDeliveryEndDateTime()));
      }

      buffer.append("IsImplied=").append(tradeMessage.IsImplied);
      buffer.append(", IsSystemPricedLeg=").append(tradeMessage.IsSystemPricedLeg);

      if(tradeMessage.IsSystemPricedLeg=='Y' && tradeMessage.SystemPricedLegType!=' ')
      {
         buffer.append(" [SystemPricedLegType=").append(tradeMessage.SystemPricedLegType).append("]");
      }

      if(tradeMessage.BlockTradeType[0]!=' ')
      {
         String blockTradeType = new String(tradeMessage.BlockTradeType);
         String tradeTypeDesc = TradeMessageHandler.getOffExchangeDealTradeType(blockTradeType.trim());
         buffer.append(" : [").append(tradeTypeDesc).append("]");
      }
      Object altPrice = tradeMessage.getFieldValue(SpecialFieldValue.ALT_PRICE);
      if ( altPrice != null ) {
         buffer.append(" [AltPrice=").append(altPrice).append("]");
      }

      InvestigationStatus investigationStatus=trade.getInvestigationStatus();

      if(investigationStatus!=null)
      {
         buffer.append(" : [").append(investigationStatus.getStatusDescription()).append("]");
      }

      if(trade.isCancelled())
      {
         buffer.append(" : <<CANCELLED>>");
      }

      if (trade.isAdjusted())
      {
         buffer.append(" : <<ADJUSTED>>");
      }



      return(buffer.toString());
   }

   /**
    * initialize
    */
   public void init()
   {
   }

   public void cleanup()
   {
   }


}

