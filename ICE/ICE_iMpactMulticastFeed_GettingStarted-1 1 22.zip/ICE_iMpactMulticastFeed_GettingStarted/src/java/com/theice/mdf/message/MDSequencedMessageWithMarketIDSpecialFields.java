package com.theice.mdf.message;

import com.theice.mdf.message.notification.SpecialFieldMessage;

import java.util.ArrayList;
import java.util.List;

/**
 * User: dkim
 * Date: 10/22/14
 * Time: 9:37 AM
 */
public abstract class MDSequencedMessageWithMarketIDSpecialFields extends MDSequencedMessageWithMarketID implements SupportSpecialFieldMessage{

   public MDSequencedMessageWithMarketIDSpecialFields()
   {
      super();
   }

   public MDSequencedMessageWithMarketIDSpecialFields(MDSequencedMessageWithMarketID mdMsg)
   {
      super(mdMsg);
   }

   public List<SpecialFieldValue> specialFieldValues;

   public void addField( byte fieldId, Object value ) {
      if ( specialFieldValues == null )
         specialFieldValues = new ArrayList<SpecialFieldValue>();
      specialFieldValues.add(new SpecialFieldValue(fieldId, value));
   }

   public Object getFieldValue( byte fieldId ) {
      if ( specialFieldValues ==null) return null;
      for ( int i=0; i< specialFieldValues.size(); i++ )
      {
         SpecialFieldValue value = specialFieldValues.get(i);
         if ( value.getFieldId() == fieldId)
            return value.getValue();
      }
      return null;

   }

   @Override
   public boolean hasSpecialFieldValues(){
      return specialFieldValues != null && !specialFieldValues.isEmpty();
   }

   public void setSpecialFieldMessage(SpecialFieldMessage message) {
      specialFieldValues = message.getFields();
   }

   @Override
   public SpecialFieldMessage getSpecialFieldMessage() {
      if (specialFieldValues == null || specialFieldValues.isEmpty() )
         return null;
      return new SpecialFieldMessage(this);
   }
}
