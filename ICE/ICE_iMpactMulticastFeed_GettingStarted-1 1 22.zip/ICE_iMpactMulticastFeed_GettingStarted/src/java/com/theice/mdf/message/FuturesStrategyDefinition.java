package com.theice.mdf.message;

import com.theice.mdf.message.response.FuturesStrategyLegDefinition;

public class FuturesStrategyDefinition
{
   public static final short CONTRACT_SYMBOL_LENGTH = 70;
   private int marketID;
   private char[] contractSymbol = new char[CONTRACT_SYMBOL_LENGTH];
   private char tradingStatus;
   private char orderPriceDenominator;
   private int incrementPrice;
   private int incrementQty;
   private int minQty;
   private FuturesStrategyLegDefinition[] _legDefinitions;
   private short securitySubType;
   private char IsBlockOnly;

   public int getMarketID()
   {
      return marketID;
   }
   public void setMarketID(int marketID)
   {
      this.marketID = marketID;
   }

   public char[] getContractSymbol()
   {
      return contractSymbol;
   }
   
   public void setContractSymbol(char[] contractSymbol)
   {
      this.contractSymbol = contractSymbol;
   }
   public char getTradingStatus()
   {
      return tradingStatus;
   }
   public void setTradingStatus(char tradingStatus)
   {
      this.tradingStatus = tradingStatus;
   }
   public char getOrderPriceDenominator()
   {
      return orderPriceDenominator;
   }
   public void setOrderPriceDenominator(char orderPriceDenominator)
   {
      this.orderPriceDenominator = orderPriceDenominator;
   }
   public int getIncrementPrice()
   {
      return incrementPrice;
   }
   public void setIncrementPrice(int incrementPrice)
   {
      this.incrementPrice = incrementPrice;
   }
   public int getIncrementQty()
   {
      return incrementQty;
   }
   public void setIncrementQty(int incrementQty)
   {
      this.incrementQty = incrementQty;
   }
   public int getMinQty()
   {
      return minQty;
   }
   public void setMinQty(int minQty)
   {
      this.minQty = minQty;
   }
   public FuturesStrategyLegDefinition[] getLegDefinitions()
   {
      return _legDefinitions;
   }
   public void setLegDefinitions(FuturesStrategyLegDefinition[] legDefinitions)
   {
      _legDefinitions = legDefinitions;
   }
   
   public int getNumberOfLegDefinitions()
   {
      return _legDefinitions==null? 0 : _legDefinitions.length;
   }
   
   public void setSecuritySubType(short type)
   {
   	securitySubType = type;
   }
   
   public short getSecuritySubType()
   {
   	return securitySubType;
   }

   public char getIsBlockOnly() {
      return IsBlockOnly;
   }

   public void setIsBlockOnly(char isBlockOnly) {
      IsBlockOnly = isBlockOnly;
   }
}
