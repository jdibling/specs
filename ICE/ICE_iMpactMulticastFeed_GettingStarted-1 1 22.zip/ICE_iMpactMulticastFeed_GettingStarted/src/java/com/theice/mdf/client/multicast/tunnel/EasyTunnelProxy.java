package com.theice.mdf.client.multicast.tunnel;

import org.apache.log4j.Logger;

import com.theice.mdf.client.exception.InitializationException;

/**
 * THE CLASSES USED HERE, INCLUDING THE MESSSAGE CLASSES ARE EXAMPLE CODES ONLY.
 * THEY WON'T BE SUPPORTED AS LIBRARY.
 * 
 * EasyTunnelProxy
 * 
 * @author Barry Fleming
 */
public class EasyTunnelProxy extends TunnelProxy {
    private static final Logger logger = Logger.getLogger(EasyTunnelProxy.class.getName());
    public static final String COMMAND_HELP = "help";
    public static final String COMMAND_QUESTION = "?";
    public static final String COMMAND_LIST = "list";

    private static final TunnelProxyXMLConfigurator configurator;

    static {
        try {
            TunnelProxyXMLConfigurator.useXmlConfig();
        } catch (InitializationException e) {
            System.err.println("Encountered an error trying to load the addresses configuration file. Check the error log for more details.");
            logger.error("Encountered an error trying to load the addresses configuration file", e);
            System.exit(-1);
        }
        configurator = (TunnelProxyXMLConfigurator) TunnelProxyConfigurator.getInstance();
    }

    public EasyTunnelProxy() {
        super();
    }

    private static String getUsage() {
        StringBuilder sb = new StringBuilder("Usage:\n");
        sb.append("tunnelProxy [ ").append(COMMAND_HELP).append(" | ").append(COMMAND_LIST).append(" | group code name ]\n");
        sb.append("    ").append(COMMAND_HELP).append(" - displays usage\n");
        sb.append("    ").append(COMMAND_LIST).append(" - displays available groups; enter the code name to connect to the group\n\n");
        return sb.toString();
    }

    private static String getArg(String[] args, int index) {
        if (null != args && args.length > index) {
            return args[0];
        }
        return "";
    }

    private static boolean setup(String[] args) {
        boolean success = false;
        String groupName = getArg(args, 0);
        if ("".equalsIgnoreCase(groupName) || COMMAND_HELP.equalsIgnoreCase(groupName) || COMMAND_QUESTION.equalsIgnoreCase(groupName)) {
            logger.info(getUsage());
        } else if (COMMAND_LIST.equalsIgnoreCase(groupName)) {
            logger.info(configurator.getFormattedGroups());
        } else {
            success = configurator.configureGroup(groupName);
            if (false == success) {
                logger.info(groupName+" is not a valid command or group code name.\n");
                logger.info(getUsage());
            }
        }
        return success;
    }

    public static void main(String[] args) {
        boolean success = setup(args);
        if (false == success) {
            return;
        }
        logger.info("TunnelProxy connecting to " + getArg(args, 0));
        runTunnelProxy(new EasyTunnelProxy());
    }
}
