package com.theice.mdf.message.response;

import java.nio.ByteBuffer;

public class OptionStrategyHedgeDefinition
{
   public static final byte MESSAGE_LENGTH = 18;
   public int HedgeMarketID;
   public char HedgeSecurityType;
   public char HedgeSide;
   public long HedgePrice;
   public char HedgePriceDenominator;
   public short HedgeDelta;
   private byte _actualMessageLength=MESSAGE_LENGTH;

   public byte[] serialize(ByteBuffer serializedContent)
   {
      if (serializedContent == null)
      {
         return null;
      }
      
      serializedContent.put(MESSAGE_LENGTH);
      serializedContent.putInt(HedgeMarketID);
      serializedContent.put((byte)HedgeSecurityType);
      serializedContent.put((byte)HedgeSide);
      serializedContent.putLong(HedgePrice);
      serializedContent.put((byte)HedgePriceDenominator);
      serializedContent.putShort(HedgeDelta);
      
      return serializedContent.array();
   }
   
   public void deserialize( ByteBuffer inboundcontent )
   {
      _actualMessageLength = inboundcontent.get();
      HedgeMarketID = inboundcontent.getInt();
      HedgeSecurityType = (char)inboundcontent.get();
      HedgeSide = (char)inboundcontent.get();
      HedgePrice = inboundcontent.getLong();
      HedgePriceDenominator = (char)inboundcontent.get();
      HedgeDelta = inboundcontent.getShort();
   }
   
   public byte getActualMessageLength()
   {
      return _actualMessageLength;
   }
   
   public String toString()
   {
      //noinspection StringBufferReplaceableByString
      StringBuilder strBuilder = new StringBuilder("OptionStrategyHedgeDefinition|MessageLength=");
      strBuilder.append(_actualMessageLength);
      strBuilder.append("|HedgeMarketID=");
      strBuilder.append(HedgeMarketID);
      strBuilder.append("|HedgeSecurityType=");
      strBuilder.append(HedgeSecurityType);
      strBuilder.append("|HedgeSide=");
      strBuilder.append(HedgeSide);
      strBuilder.append("|HedgePrice=");
      strBuilder.append(HedgePrice);
      strBuilder.append("|HedgePriceDenominator=");
      strBuilder.append(HedgePriceDenominator);
      strBuilder.append("|HedgeDelta=");
      strBuilder.append(HedgeDelta);
      strBuilder.append("|");
      
      return strBuilder.toString();
   }

   @Override
   public boolean equals(Object o) {
      if (this == o) return true;
      if (!(o instanceof OptionStrategyHedgeDefinition)) return false;

      OptionStrategyHedgeDefinition that = (OptionStrategyHedgeDefinition) o;

      if (HedgeMarketID != that.HedgeMarketID) return false;
      if (HedgeSecurityType != that.HedgeSecurityType) return false;
      if (HedgeSide != that.HedgeSide) return false;
      if (HedgePrice != that.HedgePrice) return false;
      if (HedgePriceDenominator != that.HedgePriceDenominator) return false;
      if (HedgeDelta != that.HedgeDelta) return false;
      return _actualMessageLength == that._actualMessageLength;

   }

   @Override
   public int hashCode() {
      int result = HedgeMarketID;
      result = 31 * result + (int) HedgeSecurityType;
      result = 31 * result + (int) HedgeSide;
      result = 31 * result + (int) (HedgePrice ^ (HedgePrice >>> 32));
      result = 31 * result + (int) HedgePriceDenominator;
      result = 31 * result + (int) HedgeDelta;
      result = 31 * result + (int) _actualMessageLength;
      return result;
   }
}
