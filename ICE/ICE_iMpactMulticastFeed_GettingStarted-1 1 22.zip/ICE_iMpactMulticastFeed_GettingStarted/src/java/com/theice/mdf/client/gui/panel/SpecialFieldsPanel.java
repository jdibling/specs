package com.theice.mdf.client.gui.panel;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.swing.BorderFactory;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;

import com.theice.mdf.client.domain.MarketInterface;
import com.theice.mdf.client.domain.MarketStatistics;
import com.theice.mdf.client.domain.SpecialField;
import com.theice.mdf.message.SpecialFieldValue;

/**
 * THE CLASSES USED HERE, INCLUDING THE MESSAGE CLASSES ARE EXAMPLE CODES ONLY.
 * THEY WON'T BE SUPPORTED AS LIBRARY.
 * 
 * @author Barry Fleming
 * Date: Dec 17, 2014
 */
public class SpecialFieldsPanel extends JPanel {
    private static final long serialVersionUID = 1L;
    private static final Font font = new Font("Arial", Font.PLAIN, 12);
    private static final Color bgColorField = new Color(2, 2, 82);
    private static final Color bgColorPanel = new Color(204, 204, 204);

    protected final MarketInterface market;
    private final GridBagConstraints gbc;
    protected final Map<String, LabelledTextField> specialFields = new LinkedHashMap<String, LabelledTextField>();

    public SpecialFieldsPanel(MarketInterface market) {
        super(new BorderLayout());
        this.market = market;
        gbc = new GridBagConstraints(0, 1, 1, 1, 2, 2, GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(2, 2, 2, 4), 1, 1);
        buildPanel();
    }

    /**
     * init components to display the statistics
     * 
     * @param Market
     */
    private void buildPanel() {
        buildSpecialFields();
        refresh();
        JPanel contentPanel = buildContentPanel();
        buildMasterPanel(contentPanel);
    }

    private void buildMasterPanel(JPanel contentPanel) {
        JPanel masterPanel = new JPanel(new BorderLayout());
        masterPanel.add(contentPanel, BorderLayout.CENTER);
        masterPanel.add(new JLabel(" "), BorderLayout.SOUTH);
        masterPanel.setBorder(new TitledBorder(BorderFactory.createLineBorder(Color.blue, 1), "Special Fields", TitledBorder.LEADING, TitledBorder.TOP, new Font("Arial", Font.BOLD, 12)));
        masterPanel.setBackground(bgColorPanel);
        add(new JScrollPane(masterPanel), BorderLayout.CENTER);
    }

    private JPanel buildContentPanel() {
        JPanel contentPanel = new JPanel(new GridBagLayout());
        for (LabelledTextField ltf: specialFields.values()) {
            formatTextField(ltf);
        }
        addGridComponents(1, contentPanel, specialFields);
        contentPanel.setBackground(bgColorPanel);
        return contentPanel;
    }

    protected void buildSpecialFields() {
        specialFields.put(SpecialField.getKey(SpecialFieldValue.ALT_PRICE, SpecialField.ALT_PRICE_PREFIX_OPEN), new LabelledTextField(SpecialField.ALT_PRICE_PREFIX_OPEN+SpecialFieldValue.FIELD_NAME_ALT_PRICE, new JTextField(5)));
        specialFields.put(SpecialField.getKey(SpecialFieldValue.ALT_HIGH_PRICE), new LabelledTextField(SpecialFieldValue.FIELD_NAME_ALT_HIGH_PRICE, new JTextField(5)));
        specialFields.put(SpecialField.getKey(SpecialFieldValue.ALT_LOW_PRICE), new LabelledTextField(SpecialFieldValue.FIELD_NAME_ALT_LOW_PRICE, new JTextField(5)));
        specialFields.put(SpecialField.getKey(SpecialFieldValue.ALT_VWAP), new LabelledTextField(SpecialFieldValue.FIELD_NAME_ALT_VWAP, new JTextField(5)));
        specialFields.put(SpecialField.getKey(SpecialFieldValue.ALT_PRICE, SpecialField.ALT_LAST_TRADE), new LabelledTextField(SpecialFieldValue.FIELD_NAME_ALT_LAST_TRADE_PRICE, new JTextField(5)));
    }

    private void addGridComponents(int colsPerRow, JPanel panel, Map<String, LabelledTextField> allFields) {
        int row = 0;
        for (LabelledTextField field: allFields.values()) {
            addGridComponent(0, row, 4, 4, panel, field.label);
            addGridComponent(1, row, 8, 8, panel, field.textField);
            row++;
        }
    }

    private void formatTextField(LabelledTextField labelledTextField) {
        JTextField field = labelledTextField.textField;
        field.setEditable(false);
        field.setFont(font);
        field.setBackground(bgColorField);
        field.setForeground(Color.white);
    }

    private void addGridComponent(int gridx, int gridy, int weightx, int weighty, Container container, JComponent component) {
        gbc.gridx = gridx;
        gbc.gridy = gridy;
        gbc.weightx = weightx;
        gbc.weighty = weighty;
        container.add(component, gbc);
    }

    /**
     * Refresh data from the market statistics
     */
    public synchronized void refresh() {
        synchronized (market.getUnderlyingMarket()) {
            refreshSpecialFields(market.getStatistics());
        }
    }

    private void refreshSpecialFields(MarketStatistics stats) {
        if(null != stats) {
            List<SpecialField> specialField = stats.getSpecialFieldValues();
            for (SpecialField sf: specialField) {
                LabelledTextField ltf = specialFields.get(sf.getKey());
                if(null != ltf) {
                    ltf.textField.setText(String.valueOf(sf.getValue().getValue()));
                }
            }
        }
    }

    public void cleanup() {
    }

    class LabelledTextField {
        final JLabel label;
        final JTextField textField;

        public LabelledTextField(String label, JTextField textField) {
            this.label = new JLabel(label + " : ");
            this.textField = textField;
        }
    }
}
