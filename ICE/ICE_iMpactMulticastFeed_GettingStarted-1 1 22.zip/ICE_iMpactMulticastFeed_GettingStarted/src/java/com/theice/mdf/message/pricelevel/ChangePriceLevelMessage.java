/*
 * This material may not be reproduced or redistributed in whole
 * or in part without the express prior written consent of
 * IntercontinentalExchange, Inc.
 *
 * Copyright IntercontinentalExchange, Inc. 2006, All Rights Reserved.
 */
package com.theice.mdf.message.pricelevel;

import com.theice.mdf.message.RawMessageFactory;


/**
 * @author qwang
 * @version     %I%, %G%
 * Created: Sep 26, 2007 11:04:10 AM
 *
 *
 */
public class ChangePriceLevelMessage extends AddPriceLevelMessage
{
   
   public ChangePriceLevelMessage()
   {
      MessageType = RawMessageFactory.ChangePriceLevelMessageType;
      MessageBodyLength = MESSAGE_LENGTH - HEADER_LENGTH;
   }
   

}
