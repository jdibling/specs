package com.theice.mdf.client.multicast.handler;

import java.util.List;

import com.theice.mdf.message.MDMessage;
import com.theice.mdf.message.notification.NewFuturesStrategyDefinitionMessage;
import com.theice.mdf.client.message.PriceFeedMessage;
import com.theice.mdf.client.process.AppManager;
import com.theice.mdf.client.process.handlers.AbstractMarketMessageHandler;
import com.theice.mdf.client.domain.Market;
import com.theice.mdf.client.domain.MarketInterface;
import com.theice.mdf.client.domain.MarketKey;
import com.theice.mdf.client.domain.MarketsHolder;
import com.theice.mdf.client.domain.OptionMarket;
import com.theice.mdf.client.domain.book.Book;
import com.theice.mdf.client.domain.book.FullOrderBook;
import com.theice.mdf.client.domain.book.NullBook;
import com.theice.mdf.client.domain.book.PriceLevelBook;
import com.theice.mdf.client.domain.state.MarketStreamState;

import org.apache.log4j.Logger;

public class NewFuturesStrategyDefinitionHandler extends AbstractMarketMessageHandler
{
   private static NewFuturesStrategyDefinitionHandler _instance=new NewFuturesStrategyDefinitionHandler();

   private static final Logger logger=Logger.getLogger(NewFuturesStrategyDefinitionHandler.class.getName());

   public static NewFuturesStrategyDefinitionHandler getInstance()
   {
      return _instance;
   }

   private NewFuturesStrategyDefinitionHandler()
   {
   }

   /**
    * handle the message
    * @param message
    */
   protected void handleMessage(PriceFeedMessage priceFeedMessage)
   {
      //special case
      //new UDS markets are handled in PriceLevelMulticastDispatcher (message consuming thread), which then
      //calls the processNewUDSMarketDefinition(NewOptionStrategyDefinitionMessage) method in this class.
   }
   
   public Market processNewUDSMarketDefinition(NewFuturesStrategyDefinitionMessage message)
   {
      MarketInterface market = MarketsHolder.getInstance().findMarket(message.getMarketID());
      if (market!=null)
      {
         logger.error("UDS-F market already exists. marketID="+message.getMarketID());
         return null;
      }

      Book book = null;

      switch (AppManager.getMulticastChannelContext())
      {
      case PRICELEVEL:
         book = new PriceLevelBook(MarketInterface.NUMBER_OF_PRICELEVELS);
         break;
      case FULLORDERDEPTH:
         book = new FullOrderBook();
         break;
      default:
         book = new NullBook();
         break;
      }

      Market udsMarket = null;
      try
      {
         udsMarket = new Market(message, book);
         MarketsHolder.getInstance().storeMarket(udsMarket);

         /**
          * Update the Models inside the context
          */
         AppManager.getAppContext().cacheMarket(udsMarket);
      }
      catch(Exception ex)
      {
         logger.error("Exception when initializing new UDS-F: marketID="+message.getMarketID(), ex);
         udsMarket = null;
      }

      return udsMarket;
   }

}

